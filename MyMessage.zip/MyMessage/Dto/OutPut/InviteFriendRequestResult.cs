﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirPlatform.Phone.Application.MyMessage.Dto.OutPut
{
   public  class InviteFriendRequestResult
    {
        public long Id { get; set; }

        public long UserId { get; set; }

        public string UserName { get; set; }
        public string FullName { get; set; }

        public string Relationship { get; set; }

        public string RequestTime { get; set; }

        public int Status { get; set; }
    }
}
