﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirPlatform.Phone.Application.MyMessage.Dto.OutPut
{
   public class DeviceShareRequestResult
    {
        public long Id { get; set; }

        public Guid DeviceId { get; set; }

        public string DeviceName { get; set; }

        public long ShareUserId { get; set; }

        public string Relationship { get; set; }

        public DateTime ShareRequesTime { get; set; }

        public int Status { get; set; }
    }
}
