﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp.Dependency;
using AirPlatform.Phone.Application.MyMessage.Dto.Input;
using AirPlatform.Phone.Application.MyMessage.Dto.OutPut;

namespace AirPlatform.Phone.Application.MyMessage
{
  public interface IMyMessageService:ITransientDependency
  {
        IReadOnlyList<DeviceShareRequestResult> GetDeviceShare();

        IReadOnlyList<InviteFriendRequestResult> GetInviteFriend();

        IReadOnlyList<MyMessagesOutResult> GetMyMessage(MyMessageInPutDto dto);

        MyMessageOutResult GetMyMessage(long Id);
    }
}
