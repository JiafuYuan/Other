﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using Abp.Domain.Repositories;
using AirPlatform.Core.Entities.Tables;
using AirPlatform.Phone.Application.MyMessage.Dto.Input;
using AirPlatform.Phone.Application.MyMessage.Dto.OutPut;
using AirPlatform.Phone.Core.DeviceShare;
using AirPlatform.Phone.Core.InviteFriend;

namespace AirPlatform.Phone.Application.MyMessage
{
    public class MyMessageService : PhoneApplicationAppServiceBase,IMyMessageService
    {
        private readonly IRepository<AirPlatform.Core.Entities.Tables.MyMessage, long> _myMessageRepository;
        private readonly IRepository<Device, Guid> _myDeviceRepository;
        private readonly IRepository<AirPlatform.Core.Entities.Tables.InviteFriendRequest, long> _myInviteFriendRepository;
        private readonly IRepository<AirPlatform.Core.Entities.Tables.DeviceShareRequest, long> _myDeviceShareRepository;
        private readonly IDeviceShareManager _deviceShareManager;
        private readonly IInviteFriendManager _inviteFriendManager;
        public MyMessageService(IRepository<AirPlatform.Core.Entities.Tables.MyMessage, long> myMessageRepository,
            IRepository<Device, Guid> myDeviceRepository,
            IRepository<InviteFriendRequest, long> myInviteFriendRepository, 
            IRepository<DeviceShareRequest, long> myDeviceShareRepository, 
            IDeviceShareManager deviceShareManager, 
            IInviteFriendManager inviteFriendManager)
        {
            _myDeviceRepository = myDeviceRepository;
            _myInviteFriendRepository = myInviteFriendRepository;
            _myDeviceShareRepository = myDeviceShareRepository;
            _deviceShareManager = deviceShareManager;
            _inviteFriendManager = inviteFriendManager;
            _myMessageRepository = myMessageRepository;
        }

        public IReadOnlyList<DeviceShareRequestResult> GetDeviceShare()
        {
            var userId = AbpSession.UserId;
                var deviceShare = _deviceShareManager.GetDeviceShares(userId.Value);
                return deviceShare.Select(m => new DeviceShareRequestResult()
                {
                    Id = m.Id,
                    Relationship =m.Relationship,
                    Status = m.Status,
                    DeviceName = m.DeviceName,
                    ShareRequesTime = m.ShareRequestTime,
                    DeviceId = m.DeviceId,
                    ShareUserId = m.ShareUserId
                }).ToList();
      }

        public IReadOnlyList<InviteFriendRequestResult> GetInviteFriend()
        {
            var userId = AbpSession.UserId;
            var inviteFriend = _inviteFriendManager.GetInviteFriends(userId.Value);
            return inviteFriend.Select(m => new InviteFriendRequestResult()
            {
                UserId = m.UserId,
                Id = m.Id,
                UserName = m.UserName,
                FullName = m.FullName,
                Relationship = m.Relationship,
                RequestTime = m.RequestTime.ToString("yyyy-MM-dd HH:mm:ss"),
                Status = m.Status,
            }).ToList();
        }

        public IReadOnlyList<MyMessagesOutResult> GetMyMessage(MyMessageInPutDto dto)
        {
            var userId = AbpSession.UserId;
            if (dto != null)
            {
                var myMessage = _myMessageRepository.GetAll().AsNoTracking().Where(c => c.Status == 0 && c.AcceptUserId == userId && c.CreationTime > dto.CreationTime).OrderByDescending(c => c.CreationTime);
                return myMessage.Select(m => new MyMessagesOutResult()
                {
                    Id = m.Id,
                    CreationTime = m.CreationTime,
                    Status = m.Status,
                    Title = m.Title,
                    Type = m.Type
                }).ToList();
            }
            else
            {
                var myMessage = _myMessageRepository.GetAll().AsNoTracking().Where(c => c.Status == 0 && c.AcceptUserId == userId).OrderByDescending(c => c.CreationTime);
                return myMessage.Select(m => new MyMessagesOutResult()
                {
                    Id = m.Id,
                    CreationTime = m.CreationTime,
                    Status = m.Status,
                    Title = m.Title,
                    Type = m.Type
                }).ToList();
            }
            
        }

        public MyMessageOutResult GetMyMessage(long Id)
        {
            var myMessage = _myMessageRepository.GetAll().AsNoTracking().Where(c => c.Id==Id);
            return myMessage.Select(m => new MyMessageOutResult()
            {
                Id = m.Id,
                Title = m.Title,
                Content=m.Content
            }).FirstOrDefault();
        }
    }
}
