﻿namespace VehicleTransportClient
{
    partial class FormPlanDetailQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelWorkMain = new System.Windows.Forms.Panel();
            this.panelBackMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dgback = new System.Windows.Forms.DataGridView();
            this.panel05 = new System.Windows.Forms.Panel();
            this.panelUnloadMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dgunload = new System.Windows.Forms.DataGridView();
            this.panel04 = new System.Windows.Forms.Panel();
            this.panelTransMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dghandover = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel03 = new System.Windows.Forms.Panel();
            this.panelLoadMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dgload = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel02 = new System.Windows.Forms.Panel();
            this.panelSupplyMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dggiven = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel01 = new System.Windows.Forms.Panel();
            this.panelCheckMain = new DevComponents.DotNetBar.ExpandablePanel();
            this.dgcheck = new System.Windows.Forms.DataGridView();
            this.colid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colchecknumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colcartype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colplancarnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.交接地点 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelWorkArea.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelWorkMain.SuspendLayout();
            this.panelBackMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgback)).BeginInit();
            this.panelUnloadMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgunload)).BeginInit();
            this.panelTransMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dghandover)).BeginInit();
            this.panel5.SuspendLayout();
            this.panelLoadMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgload)).BeginInit();
            this.panelSupplyMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dggiven)).BeginInit();
            this.panelCheckMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgcheck)).BeginInit();
            this.SuspendLayout();
            // 
            // panelWorkArea
            // 
            this.panelWorkArea.AutoScroll = true;
            this.panelWorkArea.Controls.Add(this.panel1);
            this.panelWorkArea.Size = new System.Drawing.Size(791, 260);
            // 
            // panelTitle
            // 
            this.panelTitle.Location = new System.Drawing.Point(83, 0);
            this.panelTitle.Size = new System.Drawing.Size(616, 28);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panelWorkMain);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(791, 260);
            this.panel1.TabIndex = 0;
            // 
            // panelWorkMain
            // 
            this.panelWorkMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panelWorkMain.AutoSize = true;
            this.panelWorkMain.Controls.Add(this.panelBackMain);
            this.panelWorkMain.Controls.Add(this.panel05);
            this.panelWorkMain.Controls.Add(this.panelUnloadMain);
            this.panelWorkMain.Controls.Add(this.panel04);
            this.panelWorkMain.Controls.Add(this.panelTransMain);
            this.panelWorkMain.Controls.Add(this.panel03);
            this.panelWorkMain.Controls.Add(this.panelLoadMain);
            this.panelWorkMain.Controls.Add(this.panel02);
            this.panelWorkMain.Controls.Add(this.panelSupplyMain);
            this.panelWorkMain.Controls.Add(this.panel01);
            this.panelWorkMain.Controls.Add(this.panelCheckMain);
            this.panelWorkMain.Location = new System.Drawing.Point(20, 15);
            this.panelWorkMain.Name = "panelWorkMain";
            this.panelWorkMain.Size = new System.Drawing.Size(752, 228);
            this.panelWorkMain.TabIndex = 1;
            // 
            // panelBackMain
            // 
            this.panelBackMain.AutoScroll = true;
            this.panelBackMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelBackMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelBackMain.Controls.Add(this.dgback);
            this.panelBackMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBackMain.Expanded = false;
            this.panelBackMain.ExpandedBounds = new System.Drawing.Rectangle(0, 180, 752, 100);
            this.panelBackMain.Location = new System.Drawing.Point(0, 180);
            this.panelBackMain.Name = "panelBackMain";
            this.panelBackMain.Size = new System.Drawing.Size(752, 26);
            this.panelBackMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelBackMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelBackMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelBackMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelBackMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelBackMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelBackMain.Style.GradientAngle = 90;
            this.panelBackMain.TabIndex = 30;
            this.panelBackMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelBackMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelBackMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelBackMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelBackMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelBackMain.TitleStyle.GradientAngle = 90;
            this.panelBackMain.TitleStyle.MarginLeft = 30;
            this.panelBackMain.TitleText = "还车";
            this.panelBackMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelBackMain_ExpandedChanged);
            // 
            // dgback
            // 
            this.dgback.AllowUserToAddRows = false;
            this.dgback.AllowUserToDeleteRows = false;
            this.dgback.AllowUserToResizeRows = false;
            this.dgback.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgback.BackgroundColor = System.Drawing.Color.White;
            this.dgback.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgback.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgback.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgback.ColumnHeadersHeight = 28;
            this.dgback.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn31,
            this.Column8,
            this.Column9,
            this.Column11,
            this.dataGridViewTextBoxColumn32});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgback.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgback.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgback.EnableHeadersVisualStyles = false;
            this.dgback.Location = new System.Drawing.Point(0, 26);
            this.dgback.Name = "dgback";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgback.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgback.RowHeadersVisible = false;
            this.dgback.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgback.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgback.RowTemplate.Height = 23;
            this.dgback.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgback.Size = new System.Drawing.Size(752, 0);
            this.dgback.TabIndex = 62;
            // 
            // panel05
            // 
            this.panel05.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel05.Location = new System.Drawing.Point(0, 170);
            this.panel05.Name = "panel05";
            this.panel05.Size = new System.Drawing.Size(752, 10);
            this.panel05.TabIndex = 29;
            // 
            // panelUnloadMain
            // 
            this.panelUnloadMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelUnloadMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelUnloadMain.Controls.Add(this.dgunload);
            this.panelUnloadMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUnloadMain.Expanded = false;
            this.panelUnloadMain.ExpandedBounds = new System.Drawing.Rectangle(0, 144, 752, 100);
            this.panelUnloadMain.Location = new System.Drawing.Point(0, 144);
            this.panelUnloadMain.Name = "panelUnloadMain";
            this.panelUnloadMain.Size = new System.Drawing.Size(752, 26);
            this.panelUnloadMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelUnloadMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelUnloadMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelUnloadMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelUnloadMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelUnloadMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelUnloadMain.Style.GradientAngle = 90;
            this.panelUnloadMain.TabIndex = 28;
            this.panelUnloadMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelUnloadMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelUnloadMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelUnloadMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelUnloadMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelUnloadMain.TitleStyle.GradientAngle = 90;
            this.panelUnloadMain.TitleStyle.MarginLeft = 30;
            this.panelUnloadMain.TitleText = "卸车";
            this.panelUnloadMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelUnloadMain_ExpandedChanged);
            // 
            // dgunload
            // 
            this.dgunload.AllowUserToAddRows = false;
            this.dgunload.AllowUserToDeleteRows = false;
            this.dgunload.AllowUserToResizeRows = false;
            this.dgunload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgunload.BackgroundColor = System.Drawing.Color.White;
            this.dgunload.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgunload.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgunload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgunload.ColumnHeadersHeight = 28;
            this.dgunload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.Column6,
            this.Column7,
            this.Column10,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgunload.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgunload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgunload.EnableHeadersVisualStyles = false;
            this.dgunload.Location = new System.Drawing.Point(0, 26);
            this.dgunload.Name = "dgunload";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgunload.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgunload.RowHeadersVisible = false;
            this.dgunload.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgunload.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgunload.RowTemplate.Height = 23;
            this.dgunload.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgunload.Size = new System.Drawing.Size(752, 0);
            this.dgunload.TabIndex = 62;
            // 
            // panel04
            // 
            this.panel04.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel04.Location = new System.Drawing.Point(0, 134);
            this.panel04.Name = "panel04";
            this.panel04.Size = new System.Drawing.Size(752, 10);
            this.panel04.TabIndex = 27;
            // 
            // panelTransMain
            // 
            this.panelTransMain.AutoScroll = true;
            this.panelTransMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelTransMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelTransMain.Controls.Add(this.dghandover);
            this.panelTransMain.Controls.Add(this.panel5);
            this.panelTransMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTransMain.Expanded = false;
            this.panelTransMain.ExpandedBounds = new System.Drawing.Rectangle(0, 108, 752, 100);
            this.panelTransMain.Location = new System.Drawing.Point(0, 108);
            this.panelTransMain.Name = "panelTransMain";
            this.panelTransMain.Size = new System.Drawing.Size(752, 26);
            this.panelTransMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelTransMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelTransMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelTransMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelTransMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelTransMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelTransMain.Style.GradientAngle = 90;
            this.panelTransMain.TabIndex = 26;
            this.panelTransMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelTransMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelTransMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelTransMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelTransMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelTransMain.TitleStyle.GradientAngle = 90;
            this.panelTransMain.TitleStyle.MarginLeft = 30;
            this.panelTransMain.TitleText = "交接车";
            this.panelTransMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelTransMain_ExpandedChanged);
            // 
            // dghandover
            // 
            this.dghandover.AllowUserToAddRows = false;
            this.dghandover.AllowUserToDeleteRows = false;
            this.dghandover.AllowUserToResizeRows = false;
            this.dghandover.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dghandover.BackgroundColor = System.Drawing.Color.White;
            this.dghandover.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dghandover.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dghandover.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dghandover.ColumnHeadersHeight = 28;
            this.dghandover.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column3,
            this.Column4,
            this.交接地点,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.Column5});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dghandover.DefaultCellStyle = dataGridViewCellStyle15;
            this.dghandover.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dghandover.EnableHeadersVisualStyles = false;
            this.dghandover.Location = new System.Drawing.Point(0, 26);
            this.dghandover.Name = "dghandover";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dghandover.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dghandover.RowHeadersVisible = false;
            this.dghandover.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dghandover.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dghandover.RowTemplate.Height = 23;
            this.dghandover.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dghandover.Size = new System.Drawing.Size(735, 55);
            this.dghandover.TabIndex = 62;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(16, 71);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(659, 10);
            this.panel5.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(28, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(659, 10);
            this.panel7.TabIndex = 21;
            // 
            // panel03
            // 
            this.panel03.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel03.Location = new System.Drawing.Point(0, 98);
            this.panel03.Name = "panel03";
            this.panel03.Size = new System.Drawing.Size(752, 10);
            this.panel03.TabIndex = 25;
            // 
            // panelLoadMain
            // 
            this.panelLoadMain.AutoScroll = true;
            this.panelLoadMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelLoadMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelLoadMain.Controls.Add(this.dgload);
            this.panelLoadMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLoadMain.Expanded = false;
            this.panelLoadMain.ExpandedBounds = new System.Drawing.Rectangle(0, 72, 752, 100);
            this.panelLoadMain.Location = new System.Drawing.Point(0, 72);
            this.panelLoadMain.Name = "panelLoadMain";
            this.panelLoadMain.Size = new System.Drawing.Size(752, 26);
            this.panelLoadMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelLoadMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelLoadMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelLoadMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelLoadMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelLoadMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelLoadMain.Style.GradientAngle = 90;
            this.panelLoadMain.TabIndex = 24;
            this.panelLoadMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelLoadMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelLoadMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelLoadMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelLoadMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelLoadMain.TitleStyle.GradientAngle = 90;
            this.panelLoadMain.TitleStyle.MarginLeft = 30;
            this.panelLoadMain.TitleText = "装车 ";
            this.panelLoadMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelLoadMain_ExpandedChanged);
            // 
            // dgload
            // 
            this.dgload.AllowUserToAddRows = false;
            this.dgload.AllowUserToDeleteRows = false;
            this.dgload.AllowUserToResizeRows = false;
            this.dgload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgload.BackgroundColor = System.Drawing.Color.White;
            this.dgload.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgload.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgload.ColumnHeadersHeight = 28;
            this.dgload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Column1,
            this.dataGridViewTextBoxColumn4});
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgload.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgload.EnableHeadersVisualStyles = false;
            this.dgload.Location = new System.Drawing.Point(0, 26);
            this.dgload.Name = "dgload";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgload.RowHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgload.RowHeadersVisible = false;
            this.dgload.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgload.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgload.RowTemplate.Height = 23;
            this.dgload.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgload.Size = new System.Drawing.Size(752, 0);
            this.dgload.TabIndex = 62;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "colid";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridViewTextBoxColumn2.FillWeight = 50F;
            this.dataGridViewTextBoxColumn2.HeaderText = "序号";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "colcartype";
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridViewTextBoxColumn3.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "货物类型";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "colplancarnumber";
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewTextBoxColumn4.HeaderText = "货物数量";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel02
            // 
            this.panel02.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel02.Location = new System.Drawing.Point(0, 62);
            this.panel02.Name = "panel02";
            this.panel02.Size = new System.Drawing.Size(752, 10);
            this.panel02.TabIndex = 23;
            // 
            // panelSupplyMain
            // 
            this.panelSupplyMain.AutoScroll = true;
            this.panelSupplyMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelSupplyMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelSupplyMain.Controls.Add(this.dggiven);
            this.panelSupplyMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSupplyMain.Expanded = false;
            this.panelSupplyMain.ExpandedBounds = new System.Drawing.Rectangle(0, 110, 752, 100);
            this.panelSupplyMain.Location = new System.Drawing.Point(0, 36);
            this.panelSupplyMain.Name = "panelSupplyMain";
            this.panelSupplyMain.Size = new System.Drawing.Size(752, 26);
            this.panelSupplyMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelSupplyMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelSupplyMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelSupplyMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelSupplyMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelSupplyMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelSupplyMain.Style.GradientAngle = 90;
            this.panelSupplyMain.TabIndex = 20;
            this.panelSupplyMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelSupplyMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelSupplyMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelSupplyMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelSupplyMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelSupplyMain.TitleStyle.GradientAngle = 90;
            this.panelSupplyMain.TitleStyle.MarginLeft = 30;
            this.panelSupplyMain.TitleText = "供车 ";
            this.panelSupplyMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelSupplyMain_ExpandedChanged);
            // 
            // dggiven
            // 
            this.dggiven.AllowUserToAddRows = false;
            this.dggiven.AllowUserToDeleteRows = false;
            this.dggiven.AllowUserToResizeRows = false;
            this.dggiven.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dggiven.BackgroundColor = System.Drawing.Color.White;
            this.dggiven.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dggiven.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dggiven.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dggiven.ColumnHeadersHeight = 28;
            this.dggiven.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dggiven.DefaultCellStyle = dataGridViewCellStyle27;
            this.dggiven.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dggiven.EnableHeadersVisualStyles = false;
            this.dggiven.Location = new System.Drawing.Point(0, 26);
            this.dggiven.Name = "dggiven";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dggiven.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dggiven.RowHeadersVisible = false;
            this.dggiven.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dggiven.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dggiven.RowTemplate.Height = 23;
            this.dggiven.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dggiven.Size = new System.Drawing.Size(752, 0);
            this.dggiven.TabIndex = 62;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "colid";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "序号";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "colcartype";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewTextBoxColumn5.HeaderText = "车辆类型";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "colplancarnumber";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn6.HeaderText = "派车数量";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // panel01
            // 
            this.panel01.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel01.Location = new System.Drawing.Point(0, 26);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(752, 10);
            this.panel01.TabIndex = 19;
            // 
            // panelCheckMain
            // 
            this.panelCheckMain.AutoScroll = true;
            this.panelCheckMain.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelCheckMain.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelCheckMain.Controls.Add(this.dgcheck);
            this.panelCheckMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCheckMain.Expanded = false;
            this.panelCheckMain.ExpandedBounds = new System.Drawing.Rectangle(0, 0, 752, 100);
            this.panelCheckMain.Location = new System.Drawing.Point(0, 0);
            this.panelCheckMain.Name = "panelCheckMain";
            this.panelCheckMain.Size = new System.Drawing.Size(752, 26);
            this.panelCheckMain.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelCheckMain.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelCheckMain.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelCheckMain.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelCheckMain.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelCheckMain.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelCheckMain.Style.GradientAngle = 90;
            this.panelCheckMain.TabIndex = 0;
            this.panelCheckMain.TitleStyle.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelCheckMain.TitleStyle.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelCheckMain.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelCheckMain.TitleStyle.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelCheckMain.TitleStyle.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelCheckMain.TitleStyle.GradientAngle = 90;
            this.panelCheckMain.TitleStyle.MarginLeft = 30;
            this.panelCheckMain.TitleText = "审核";
            this.panelCheckMain.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelCheckMain_ExpandedChanged);
            // 
            // dgcheck
            // 
            this.dgcheck.AllowUserToAddRows = false;
            this.dgcheck.AllowUserToDeleteRows = false;
            this.dgcheck.AllowUserToResizeColumns = false;
            this.dgcheck.AllowUserToResizeRows = false;
            this.dgcheck.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgcheck.BackgroundColor = System.Drawing.Color.White;
            this.dgcheck.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgcheck.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgcheck.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgcheck.ColumnHeadersHeight = 28;
            this.dgcheck.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colid,
            this.colname,
            this.colchecknumber,
            this.colcartype,
            this.colplancarnumber});
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(238)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgcheck.DefaultCellStyle = dataGridViewCellStyle34;
            this.dgcheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgcheck.EnableHeadersVisualStyles = false;
            this.dgcheck.Location = new System.Drawing.Point(0, 26);
            this.dgcheck.Name = "dgcheck";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle35.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgcheck.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.dgcheck.RowHeadersVisible = false;
            this.dgcheck.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgcheck.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgcheck.RowTemplate.Height = 23;
            this.dgcheck.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgcheck.Size = new System.Drawing.Size(752, 0);
            this.dgcheck.TabIndex = 62;
            // 
            // colid
            // 
            this.colid.DataPropertyName = "colid";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.colid.DefaultCellStyle = dataGridViewCellStyle30;
            this.colid.FillWeight = 50F;
            this.colid.HeaderText = "序号";
            this.colid.Name = "colid";
            this.colid.ReadOnly = true;
            this.colid.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colname
            // 
            this.colname.DataPropertyName = "colname";
            this.colname.HeaderText = "物料名称";
            this.colname.Name = "colname";
            this.colname.ReadOnly = true;
            this.colname.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colchecknumber
            // 
            this.colchecknumber.DataPropertyName = "colchecknumber";
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.White;
            this.colchecknumber.DefaultCellStyle = dataGridViewCellStyle31;
            this.colchecknumber.HeaderText = "审核数量";
            this.colchecknumber.Name = "colchecknumber";
            this.colchecknumber.ReadOnly = true;
            this.colchecknumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colcartype
            // 
            this.colcartype.DataPropertyName = "colcartype";
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            this.colcartype.DefaultCellStyle = dataGridViewCellStyle32;
            this.colcartype.HeaderText = "车辆类型";
            this.colcartype.Name = "colcartype";
            this.colcartype.ReadOnly = true;
            this.colcartype.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colcartype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colplancarnumber
            // 
            this.colplancarnumber.DataPropertyName = "colplancarnumber";
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.White;
            this.colplancarnumber.DefaultCellStyle = dataGridViewCellStyle33;
            this.colplancarnumber.HeaderText = "派车数量";
            this.colplancarnumber.Name = "colplancarnumber";
            this.colplancarnumber.ReadOnly = true;
            this.colplancarnumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "colid";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn27.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn27.FillWeight = 50F;
            this.dataGridViewTextBoxColumn27.HeaderText = "序号";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "卸车人";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "时间";
            this.Column7.Name = "Column7";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "地点";
            this.Column10.Name = "Column10";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "colcartype";
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn28.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn28.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "货物类型";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "colplancarnumber";
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn30.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn30.HeaderText = "货物数量";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "colid";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn31.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn31.FillWeight = 50F;
            this.dataGridViewTextBoxColumn31.HeaderText = "序号";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "还车人";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "时间";
            this.Column9.Name = "Column9";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "地点";
            this.Column11.Name = "Column11";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "colcartype";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn32.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn32.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "交接次数";
            this.Column2.Name = "Column2";
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "交接人";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "时间";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // 交接地点
            // 
            this.交接地点.HeaderText = "地点";
            this.交接地点.Name = "交接地点";
            this.交接地点.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "colcartype";
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn8.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "货物类型";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "colplancarnumber";
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.White;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn10.HeaderText = "货物数量";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "相差数量";
            this.Column5.Name = "Column5";
            // 
            // FormPlanDetailQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(793, 290);
            this.FormTitle = "运单明细";
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "FormPlanDetailQuery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "运单明细";
            this.panelWorkArea.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelWorkMain.ResumeLayout(false);
            this.panelBackMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgback)).EndInit();
            this.panelUnloadMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgunload)).EndInit();
            this.panelTransMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dghandover)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panelLoadMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgload)).EndInit();
            this.panelSupplyMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dggiven)).EndInit();
            this.panelCheckMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgcheck)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelWorkMain;
        private DevComponents.DotNetBar.ExpandablePanel panelCheckMain;
        private System.Windows.Forms.DataGridView dgcheck;
        private DevComponents.DotNetBar.ExpandablePanel panelBackMain;
        private System.Windows.Forms.DataGridView dgback;
        private System.Windows.Forms.Panel panel05;
        private DevComponents.DotNetBar.ExpandablePanel panelUnloadMain;
        private System.Windows.Forms.DataGridView dgunload;
        private System.Windows.Forms.Panel panel04;
        private DevComponents.DotNetBar.ExpandablePanel panelTransMain;
        private System.Windows.Forms.DataGridView dghandover;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel03;
        private DevComponents.DotNetBar.ExpandablePanel panelLoadMain;
        private System.Windows.Forms.DataGridView dgload;
        private System.Windows.Forms.Panel panel02;
        private DevComponents.DotNetBar.ExpandablePanel panelSupplyMain;
        private System.Windows.Forms.DataGridView dggiven;
        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colname;
        private System.Windows.Forms.DataGridViewTextBoxColumn colchecknumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn colcartype;
        private System.Windows.Forms.DataGridViewTextBoxColumn colplancarnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn 交接地点;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;




    }
}