﻿namespace VehicleTransportClient
{
    partial class FormCurrentAlarm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCurrentAlarm));
            this.balloonTip1 = new DevComponents.DotNetBar.BalloonTip();
            this.TabControlCurrentAlarm = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel14 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListNoChanageStateAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn76 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn77 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn78 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn84 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip17 = new System.Windows.Forms.ToolStrip();
            this.btnReNoChanageStateAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnNoChanageStateAlarm = new System.Windows.Forms.ToolStripButton();
            this.TabItemNoChanageStateAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel13 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListRunDerictionAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn73 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn74 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn75 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn83 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip16 = new System.Windows.Forms.ToolStrip();
            this.btnSxRunDerictionAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsRunDerictionAlarm = new System.Windows.Forms.ToolStripButton();
            this.TabItemRunDerictionAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel12 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListNoUseAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn71 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn82 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip15 = new System.Windows.Forms.ToolStrip();
            this.btnSxNoUseAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsNoUseAlarm = new System.Windows.Forms.ToolStripButton();
            this.TabItemNoUseAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel10 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListBackTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn69 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn81 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip14 = new System.Windows.Forms.ToolStrip();
            this.btnSxBackTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsBackTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.toolStrip10 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.TabItemBackTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel6 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListUnLoadTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn80 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip13 = new System.Windows.Forms.ToolStrip();
            this.btnSxUnLoadTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsUnLoadTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.toolStrip6 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.TabItemUnLoadTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel5 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListTransportTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn63 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn79 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip12 = new System.Windows.Forms.ToolStrip();
            this.btnSxTransportTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsTransportTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.toolStrip5 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.TabItemTransportTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel4 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListLoadTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.btnSxLoadTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsLoadTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.TabItemLoadTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListGiveTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip18 = new System.Windows.Forms.ToolStrip();
            this.btnSxGcAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsGcAlarm = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btnSxGiveTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsGiveTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.TabItemGiveTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListScrapTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip19 = new System.Windows.Forms.ToolStrip();
            this.btnSxCq = new System.Windows.Forms.ToolStripButton();
            this.btnYsCq = new System.Windows.Forms.ToolStripButton();
            this.toolStrip11 = new System.Windows.Forms.ToolStrip();
            this.btnSxScrapTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.btnYsScrapTimeOutAlarm = new System.Windows.Forms.ToolStripButton();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.TabItemScrapTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dgvListMaintainTimeOutAlarm = new VehicleTransportClient.Tools.DataGridViewEx();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vc_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnRefresh = new System.Windows.Forms.ToolStripButton();
            this.btnStyle = new System.Windows.Forms.ToolStripButton();
            this.TabItemMaintainTimeOutAlarm = new DevComponents.DotNetBar.SuperTabItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelWorkArea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TabControlCurrentAlarm)).BeginInit();
            this.TabControlCurrentAlarm.SuspendLayout();
            this.superTabControlPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListNoChanageStateAlarm)).BeginInit();
            this.toolStrip17.SuspendLayout();
            this.superTabControlPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListRunDerictionAlarm)).BeginInit();
            this.toolStrip16.SuspendLayout();
            this.superTabControlPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListNoUseAlarm)).BeginInit();
            this.toolStrip15.SuspendLayout();
            this.superTabControlPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListBackTimeOutAlarm)).BeginInit();
            this.toolStrip14.SuspendLayout();
            this.toolStrip10.SuspendLayout();
            this.superTabControlPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListUnLoadTimeOutAlarm)).BeginInit();
            this.toolStrip13.SuspendLayout();
            this.toolStrip6.SuspendLayout();
            this.superTabControlPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListTransportTimeOutAlarm)).BeginInit();
            this.toolStrip12.SuspendLayout();
            this.toolStrip5.SuspendLayout();
            this.superTabControlPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListLoadTimeOutAlarm)).BeginInit();
            this.toolStrip4.SuspendLayout();
            this.superTabControlPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListGiveTimeOutAlarm)).BeginInit();
            this.toolStrip18.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListScrapTimeOutAlarm)).BeginInit();
            this.toolStrip19.SuspendLayout();
            this.toolStrip11.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.superTabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListMaintainTimeOutAlarm)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelWorkArea
            // 
            this.panelWorkArea.Controls.Add(this.statusStrip1);
            this.panelWorkArea.Controls.Add(this.TabControlCurrentAlarm);
            this.panelWorkArea.Dock = System.Windows.Forms.DockStyle.None;
            this.panelWorkArea.Location = new System.Drawing.Point(0, 27);
            this.panelWorkArea.Size = new System.Drawing.Size(1166, 523);
            // 
            // panelTitle
            // 
            this.panelTitle.Size = new System.Drawing.Size(1012, 28);
            // 
            // balloonTip1
            // 
            this.balloonTip1.AlertAnimation = DevComponents.DotNetBar.eAlertAnimation.LeftToRight;
            this.balloonTip1.DefaultBalloonWidth = 100;
            this.balloonTip1.MinimumBalloonWidth = 100;
            // 
            // TabControlCurrentAlarm
            // 
            this.TabControlCurrentAlarm.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            // 
            // 
            // 
            this.TabControlCurrentAlarm.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.TabControlCurrentAlarm.ControlBox.MenuBox.Name = "";
            this.TabControlCurrentAlarm.ControlBox.Name = "";
            this.TabControlCurrentAlarm.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.TabControlCurrentAlarm.ControlBox.MenuBox,
            this.TabControlCurrentAlarm.ControlBox.CloseBox});
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel1);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel14);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel13);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel12);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel10);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel6);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel5);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel4);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel3);
            this.TabControlCurrentAlarm.Controls.Add(this.superTabControlPanel2);
            this.TabControlCurrentAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControlCurrentAlarm.Location = new System.Drawing.Point(0, 0);
            this.TabControlCurrentAlarm.Name = "TabControlCurrentAlarm";
            this.TabControlCurrentAlarm.ReorderTabsEnabled = true;
            this.TabControlCurrentAlarm.SelectedTabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.TabControlCurrentAlarm.SelectedTabIndex = 0;
            this.TabControlCurrentAlarm.Size = new System.Drawing.Size(1166, 523);
            this.TabControlCurrentAlarm.TabFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TabControlCurrentAlarm.TabIndex = 16;
            this.TabControlCurrentAlarm.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.TabItemMaintainTimeOutAlarm,
            this.TabItemScrapTimeOutAlarm,
            this.TabItemGiveTimeOutAlarm,
            this.TabItemLoadTimeOutAlarm,
            this.TabItemTransportTimeOutAlarm,
            this.TabItemUnLoadTimeOutAlarm,
            this.TabItemBackTimeOutAlarm,
            this.TabItemNoUseAlarm,
            this.TabItemRunDerictionAlarm,
            this.TabItemNoChanageStateAlarm});
            this.TabControlCurrentAlarm.Text = "superTabControl1";
            // 
            // superTabControlPanel14
            // 
            this.superTabControlPanel14.Controls.Add(this.dgvListNoChanageStateAlarm);
            this.superTabControlPanel14.Controls.Add(this.toolStrip17);
            this.superTabControlPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel14.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel14.Name = "superTabControlPanel14";
            this.superTabControlPanel14.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel14.TabIndex = 0;
            this.superTabControlPanel14.TabItem = this.TabItemNoChanageStateAlarm;
            // 
            // dgvListNoChanageStateAlarm
            // 
            this.dgvListNoChanageStateAlarm.AllowUserToAddRows = false;
            this.dgvListNoChanageStateAlarm.AllowUserToDeleteRows = false;
            this.dgvListNoChanageStateAlarm.AllowUserToResizeRows = false;
            this.dgvListNoChanageStateAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListNoChanageStateAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvListNoChanageStateAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListNoChanageStateAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListNoChanageStateAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListNoChanageStateAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListNoChanageStateAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListNoChanageStateAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvListNoChanageStateAlarm.ColumnHeadersHeight = 35;
            this.dgvListNoChanageStateAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListNoChanageStateAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn76,
            this.dataGridViewTextBoxColumn77,
            this.dataGridViewTextBoxColumn78,
            this.dataGridViewTextBoxColumn84});
            this.dgvListNoChanageStateAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListNoChanageStateAlarm.EnableHeadersVisualStyles = false;
            this.dgvListNoChanageStateAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListNoChanageStateAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListNoChanageStateAlarm.MultiSelect = false;
            this.dgvListNoChanageStateAlarm.Name = "dgvListNoChanageStateAlarm";
            this.dgvListNoChanageStateAlarm.ReadOnly = true;
            this.dgvListNoChanageStateAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListNoChanageStateAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvListNoChanageStateAlarm.RowHeadersVisible = false;
            this.dgvListNoChanageStateAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListNoChanageStateAlarm.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvListNoChanageStateAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListNoChanageStateAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListNoChanageStateAlarm.RowTemplate.Height = 35;
            this.dgvListNoChanageStateAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListNoChanageStateAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListNoChanageStateAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListNoChanageStateAlarm.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn76
            // 
            this.dataGridViewTextBoxColumn76.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn76.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn76.Name = "dataGridViewTextBoxColumn76";
            this.dataGridViewTextBoxColumn76.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn77
            // 
            this.dataGridViewTextBoxColumn77.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn77.HeaderText = "申请部门";
            this.dataGridViewTextBoxColumn77.Name = "dataGridViewTextBoxColumn77";
            this.dataGridViewTextBoxColumn77.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn78
            // 
            this.dataGridViewTextBoxColumn78.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn78.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn78.Name = "dataGridViewTextBoxColumn78";
            this.dataGridViewTextBoxColumn78.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn84
            // 
            this.dataGridViewTextBoxColumn84.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn84.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn84.Name = "dataGridViewTextBoxColumn84";
            this.dataGridViewTextBoxColumn84.ReadOnly = true;
            // 
            // toolStrip17
            // 
            this.toolStrip17.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip17.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnReNoChanageStateAlarm,
            this.btnNoChanageStateAlarm});
            this.toolStrip17.Location = new System.Drawing.Point(0, 0);
            this.toolStrip17.Name = "toolStrip17";
            this.toolStrip17.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip17.TabIndex = 14;
            this.toolStrip17.Text = "toolStrip17";
            // 
            // btnReNoChanageStateAlarm
            // 
            this.btnReNoChanageStateAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnReNoChanageStateAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReNoChanageStateAlarm.Name = "btnReNoChanageStateAlarm";
            this.btnReNoChanageStateAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnReNoChanageStateAlarm.Text = "刷新";
            this.btnReNoChanageStateAlarm.Click += new System.EventHandler(this.btnReNoChanageStateAlarm_Click);
            // 
            // btnNoChanageStateAlarm
            // 
            this.btnNoChanageStateAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnNoChanageStateAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNoChanageStateAlarm.Name = "btnNoChanageStateAlarm";
            this.btnNoChanageStateAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnNoChanageStateAlarm.Text = "样式";
            this.btnNoChanageStateAlarm.Click += new System.EventHandler(this.btnNoChanageStateAlarm_Click);
            // 
            // TabItemNoChanageStateAlarm
            // 
            this.TabItemNoChanageStateAlarm.AttachedControl = this.superTabControlPanel14;
            this.TabItemNoChanageStateAlarm.GlobalItem = false;
            this.TabItemNoChanageStateAlarm.Name = "TabItemNoChanageStateAlarm";
            this.TabItemNoChanageStateAlarm.Text = "未置换状态告警";
            this.TabItemNoChanageStateAlarm.Click += new System.EventHandler(this.TabItemNoChanageStateAlarm_Click);
            // 
            // superTabControlPanel13
            // 
            this.superTabControlPanel13.Controls.Add(this.dgvListRunDerictionAlarm);
            this.superTabControlPanel13.Controls.Add(this.toolStrip16);
            this.superTabControlPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel13.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel13.Name = "superTabControlPanel13";
            this.superTabControlPanel13.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel13.TabIndex = 0;
            this.superTabControlPanel13.TabItem = this.TabItemRunDerictionAlarm;
            // 
            // dgvListRunDerictionAlarm
            // 
            this.dgvListRunDerictionAlarm.AllowUserToAddRows = false;
            this.dgvListRunDerictionAlarm.AllowUserToDeleteRows = false;
            this.dgvListRunDerictionAlarm.AllowUserToResizeRows = false;
            this.dgvListRunDerictionAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListRunDerictionAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvListRunDerictionAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListRunDerictionAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListRunDerictionAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListRunDerictionAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListRunDerictionAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListRunDerictionAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvListRunDerictionAlarm.ColumnHeadersHeight = 35;
            this.dgvListRunDerictionAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListRunDerictionAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn73,
            this.dataGridViewTextBoxColumn74,
            this.dataGridViewTextBoxColumn75,
            this.dataGridViewTextBoxColumn83});
            this.dgvListRunDerictionAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListRunDerictionAlarm.EnableHeadersVisualStyles = false;
            this.dgvListRunDerictionAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListRunDerictionAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListRunDerictionAlarm.MultiSelect = false;
            this.dgvListRunDerictionAlarm.Name = "dgvListRunDerictionAlarm";
            this.dgvListRunDerictionAlarm.ReadOnly = true;
            this.dgvListRunDerictionAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListRunDerictionAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvListRunDerictionAlarm.RowHeadersVisible = false;
            this.dgvListRunDerictionAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListRunDerictionAlarm.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvListRunDerictionAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListRunDerictionAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListRunDerictionAlarm.RowTemplate.Height = 35;
            this.dgvListRunDerictionAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListRunDerictionAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListRunDerictionAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListRunDerictionAlarm.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn73
            // 
            this.dataGridViewTextBoxColumn73.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn73.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn73.Name = "dataGridViewTextBoxColumn73";
            this.dataGridViewTextBoxColumn73.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn74
            // 
            this.dataGridViewTextBoxColumn74.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn74.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn74.Name = "dataGridViewTextBoxColumn74";
            this.dataGridViewTextBoxColumn74.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn75
            // 
            this.dataGridViewTextBoxColumn75.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn75.HeaderText = "车辆名称";
            this.dataGridViewTextBoxColumn75.Name = "dataGridViewTextBoxColumn75";
            this.dataGridViewTextBoxColumn75.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn83
            // 
            this.dataGridViewTextBoxColumn83.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn83.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn83.Name = "dataGridViewTextBoxColumn83";
            this.dataGridViewTextBoxColumn83.ReadOnly = true;
            // 
            // toolStrip16
            // 
            this.toolStrip16.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip16.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxRunDerictionAlarm,
            this.btnYsRunDerictionAlarm});
            this.toolStrip16.Location = new System.Drawing.Point(0, 0);
            this.toolStrip16.Name = "toolStrip16";
            this.toolStrip16.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip16.TabIndex = 14;
            this.toolStrip16.Text = "toolStrip16";
            // 
            // btnSxRunDerictionAlarm
            // 
            this.btnSxRunDerictionAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxRunDerictionAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxRunDerictionAlarm.Name = "btnSxRunDerictionAlarm";
            this.btnSxRunDerictionAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxRunDerictionAlarm.Text = "刷新";
            this.btnSxRunDerictionAlarm.Click += new System.EventHandler(this.btnSxRunDerictionAlarm_Click);
            // 
            // btnYsRunDerictionAlarm
            // 
            this.btnYsRunDerictionAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsRunDerictionAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsRunDerictionAlarm.Name = "btnYsRunDerictionAlarm";
            this.btnYsRunDerictionAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsRunDerictionAlarm.Text = "样式";
            this.btnYsRunDerictionAlarm.Click += new System.EventHandler(this.btnYsRunDerictionAlarm_Click);
            // 
            // TabItemRunDerictionAlarm
            // 
            this.TabItemRunDerictionAlarm.AttachedControl = this.superTabControlPanel13;
            this.TabItemRunDerictionAlarm.GlobalItem = false;
            this.TabItemRunDerictionAlarm.Name = "TabItemRunDerictionAlarm";
            this.TabItemRunDerictionAlarm.Text = "运行方向不正确告警";
            this.TabItemRunDerictionAlarm.Click += new System.EventHandler(this.TabItemRunDerictionAlarm_Click);
            // 
            // superTabControlPanel12
            // 
            this.superTabControlPanel12.Controls.Add(this.dgvListNoUseAlarm);
            this.superTabControlPanel12.Controls.Add(this.toolStrip15);
            this.superTabControlPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel12.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel12.Name = "superTabControlPanel12";
            this.superTabControlPanel12.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel12.TabIndex = 0;
            this.superTabControlPanel12.TabItem = this.TabItemNoUseAlarm;
            // 
            // dgvListNoUseAlarm
            // 
            this.dgvListNoUseAlarm.AllowUserToAddRows = false;
            this.dgvListNoUseAlarm.AllowUserToDeleteRows = false;
            this.dgvListNoUseAlarm.AllowUserToResizeRows = false;
            this.dgvListNoUseAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListNoUseAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvListNoUseAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListNoUseAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListNoUseAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListNoUseAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListNoUseAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListNoUseAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvListNoUseAlarm.ColumnHeadersHeight = 35;
            this.dgvListNoUseAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListNoUseAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn71,
            this.dataGridViewTextBoxColumn72,
            this.Column1,
            this.dataGridViewTextBoxColumn82});
            this.dgvListNoUseAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListNoUseAlarm.EnableHeadersVisualStyles = false;
            this.dgvListNoUseAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListNoUseAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListNoUseAlarm.MultiSelect = false;
            this.dgvListNoUseAlarm.Name = "dgvListNoUseAlarm";
            this.dgvListNoUseAlarm.ReadOnly = true;
            this.dgvListNoUseAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListNoUseAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvListNoUseAlarm.RowHeadersVisible = false;
            this.dgvListNoUseAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListNoUseAlarm.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvListNoUseAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListNoUseAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListNoUseAlarm.RowTemplate.Height = 35;
            this.dgvListNoUseAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListNoUseAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListNoUseAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListNoUseAlarm.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn71
            // 
            this.dataGridViewTextBoxColumn71.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn71.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn71.Name = "dataGridViewTextBoxColumn71";
            this.dataGridViewTextBoxColumn71.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn72
            // 
            this.dataGridViewTextBoxColumn72.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn72.HeaderText = "车辆名称";
            this.dataGridViewTextBoxColumn72.Name = "dataGridViewTextBoxColumn72";
            this.dataGridViewTextBoxColumn72.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "当前基站";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn82
            // 
            this.dataGridViewTextBoxColumn82.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn82.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn82.Name = "dataGridViewTextBoxColumn82";
            this.dataGridViewTextBoxColumn82.ReadOnly = true;
            // 
            // toolStrip15
            // 
            this.toolStrip15.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip15.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxNoUseAlarm,
            this.btnYsNoUseAlarm});
            this.toolStrip15.Location = new System.Drawing.Point(0, 0);
            this.toolStrip15.Name = "toolStrip15";
            this.toolStrip15.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip15.TabIndex = 14;
            this.toolStrip15.Text = "toolStrip15";
            // 
            // btnSxNoUseAlarm
            // 
            this.btnSxNoUseAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxNoUseAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxNoUseAlarm.Name = "btnSxNoUseAlarm";
            this.btnSxNoUseAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxNoUseAlarm.Text = "刷新";
            this.btnSxNoUseAlarm.Click += new System.EventHandler(this.btnSxNoUseAlarm_Click);
            // 
            // btnYsNoUseAlarm
            // 
            this.btnYsNoUseAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsNoUseAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsNoUseAlarm.Name = "btnYsNoUseAlarm";
            this.btnYsNoUseAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsNoUseAlarm.Text = "样式";
            this.btnYsNoUseAlarm.Click += new System.EventHandler(this.btnYsNoUseAlarm_Click);
            // 
            // TabItemNoUseAlarm
            // 
            this.TabItemNoUseAlarm.AttachedControl = this.superTabControlPanel12;
            this.TabItemNoUseAlarm.GlobalItem = false;
            this.TabItemNoUseAlarm.Name = "TabItemNoUseAlarm";
            this.TabItemNoUseAlarm.Text = "闲置告警";
            this.TabItemNoUseAlarm.Click += new System.EventHandler(this.TabItemNoUseAlarm_Click);
            // 
            // superTabControlPanel10
            // 
            this.superTabControlPanel10.Controls.Add(this.dgvListBackTimeOutAlarm);
            this.superTabControlPanel10.Controls.Add(this.toolStrip14);
            this.superTabControlPanel10.Controls.Add(this.toolStrip10);
            this.superTabControlPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel10.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel10.Name = "superTabControlPanel10";
            this.superTabControlPanel10.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel10.TabIndex = 0;
            this.superTabControlPanel10.TabItem = this.TabItemBackTimeOutAlarm;
            // 
            // dgvListBackTimeOutAlarm
            // 
            this.dgvListBackTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListBackTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListBackTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListBackTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListBackTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvListBackTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListBackTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListBackTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListBackTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListBackTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListBackTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvListBackTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListBackTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListBackTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn67,
            this.dataGridViewTextBoxColumn68,
            this.dataGridViewTextBoxColumn69,
            this.Column7,
            this.dataGridViewTextBoxColumn81});
            this.dgvListBackTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListBackTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListBackTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListBackTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListBackTimeOutAlarm.MultiSelect = false;
            this.dgvListBackTimeOutAlarm.Name = "dgvListBackTimeOutAlarm";
            this.dgvListBackTimeOutAlarm.ReadOnly = true;
            this.dgvListBackTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListBackTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvListBackTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListBackTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListBackTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvListBackTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListBackTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListBackTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListBackTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListBackTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListBackTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListBackTimeOutAlarm.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn67.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            this.dataGridViewTextBoxColumn67.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn68.HeaderText = "申请部门";
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            this.dataGridViewTextBoxColumn68.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn69
            // 
            this.dataGridViewTextBoxColumn69.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn69.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn69.Name = "dataGridViewTextBoxColumn69";
            this.dataGridViewTextBoxColumn69.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "计划还车部门";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn81
            // 
            this.dataGridViewTextBoxColumn81.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn81.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn81.Name = "dataGridViewTextBoxColumn81";
            this.dataGridViewTextBoxColumn81.ReadOnly = true;
            // 
            // toolStrip14
            // 
            this.toolStrip14.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip14.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxBackTimeOutAlarm,
            this.btnYsBackTimeOutAlarm});
            this.toolStrip14.Location = new System.Drawing.Point(0, 0);
            this.toolStrip14.Name = "toolStrip14";
            this.toolStrip14.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip14.TabIndex = 16;
            this.toolStrip14.Text = "toolStrip14";
            // 
            // btnSxBackTimeOutAlarm
            // 
            this.btnSxBackTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxBackTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxBackTimeOutAlarm.Name = "btnSxBackTimeOutAlarm";
            this.btnSxBackTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxBackTimeOutAlarm.Text = "刷新";
            this.btnSxBackTimeOutAlarm.Click += new System.EventHandler(this.btnSxBackTimeOutAlarm_Click);
            // 
            // btnYsBackTimeOutAlarm
            // 
            this.btnYsBackTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsBackTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsBackTimeOutAlarm.Name = "btnYsBackTimeOutAlarm";
            this.btnYsBackTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsBackTimeOutAlarm.Text = "样式";
            this.btnYsBackTimeOutAlarm.Click += new System.EventHandler(this.btnYsBackTimeOutAlarm_Click);
            // 
            // toolStrip10
            // 
            this.toolStrip10.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip10.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripButton17});
            this.toolStrip10.Location = new System.Drawing.Point(0, 0);
            this.toolStrip10.Name = "toolStrip10";
            this.toolStrip10.Size = new System.Drawing.Size(1014, 25);
            this.toolStrip10.TabIndex = 15;
            this.toolStrip10.Text = "toolStrip2";
            this.toolStrip10.Visible = false;
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton5.Text = "刷新";
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.toolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton17.Text = "样式";
            // 
            // TabItemBackTimeOutAlarm
            // 
            this.TabItemBackTimeOutAlarm.AttachedControl = this.superTabControlPanel10;
            this.TabItemBackTimeOutAlarm.GlobalItem = false;
            this.TabItemBackTimeOutAlarm.Name = "TabItemBackTimeOutAlarm";
            this.TabItemBackTimeOutAlarm.Text = "还车不及告警";
            this.TabItemBackTimeOutAlarm.Click += new System.EventHandler(this.TabItemBackTimeOutAlarm_Click);
            // 
            // superTabControlPanel6
            // 
            this.superTabControlPanel6.Controls.Add(this.dgvListUnLoadTimeOutAlarm);
            this.superTabControlPanel6.Controls.Add(this.toolStrip13);
            this.superTabControlPanel6.Controls.Add(this.toolStrip6);
            this.superTabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel6.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel6.Name = "superTabControlPanel6";
            this.superTabControlPanel6.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel6.TabIndex = 0;
            this.superTabControlPanel6.TabItem = this.TabItemUnLoadTimeOutAlarm;
            // 
            // dgvListUnLoadTimeOutAlarm
            // 
            this.dgvListUnLoadTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListUnLoadTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListUnLoadTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListUnLoadTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListUnLoadTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvListUnLoadTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListUnLoadTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListUnLoadTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListUnLoadTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListUnLoadTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListUnLoadTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvListUnLoadTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListUnLoadTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListUnLoadTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn64,
            this.dataGridViewTextBoxColumn65,
            this.dataGridViewTextBoxColumn66,
            this.dataGridViewTextBoxColumn80});
            this.dgvListUnLoadTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListUnLoadTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListUnLoadTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListUnLoadTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListUnLoadTimeOutAlarm.MultiSelect = false;
            this.dgvListUnLoadTimeOutAlarm.Name = "dgvListUnLoadTimeOutAlarm";
            this.dgvListUnLoadTimeOutAlarm.ReadOnly = true;
            this.dgvListUnLoadTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListUnLoadTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvListUnLoadTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListUnLoadTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListUnLoadTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvListUnLoadTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListUnLoadTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListUnLoadTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListUnLoadTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListUnLoadTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListUnLoadTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListUnLoadTimeOutAlarm.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn64.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            this.dataGridViewTextBoxColumn64.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn65.HeaderText = "申请部门";
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            this.dataGridViewTextBoxColumn65.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn66.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            this.dataGridViewTextBoxColumn66.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn80
            // 
            this.dataGridViewTextBoxColumn80.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn80.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn80.Name = "dataGridViewTextBoxColumn80";
            this.dataGridViewTextBoxColumn80.ReadOnly = true;
            // 
            // toolStrip13
            // 
            this.toolStrip13.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip13.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxUnLoadTimeOutAlarm,
            this.btnYsUnLoadTimeOutAlarm});
            this.toolStrip13.Location = new System.Drawing.Point(0, 0);
            this.toolStrip13.Name = "toolStrip13";
            this.toolStrip13.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip13.TabIndex = 15;
            this.toolStrip13.Text = "toolStrip13";
            // 
            // btnSxUnLoadTimeOutAlarm
            // 
            this.btnSxUnLoadTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxUnLoadTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxUnLoadTimeOutAlarm.Name = "btnSxUnLoadTimeOutAlarm";
            this.btnSxUnLoadTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxUnLoadTimeOutAlarm.Text = "刷新";
            this.btnSxUnLoadTimeOutAlarm.Click += new System.EventHandler(this.btnSxUnLoadTimeOutAlarm_Click);
            // 
            // btnYsUnLoadTimeOutAlarm
            // 
            this.btnYsUnLoadTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsUnLoadTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsUnLoadTimeOutAlarm.Name = "btnYsUnLoadTimeOutAlarm";
            this.btnYsUnLoadTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsUnLoadTimeOutAlarm.Text = "样式";
            this.btnYsUnLoadTimeOutAlarm.Click += new System.EventHandler(this.btnYsUnLoadTimeOutAlarm_Click);
            // 
            // toolStrip6
            // 
            this.toolStrip6.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton9,
            this.toolStripButton10});
            this.toolStrip6.Location = new System.Drawing.Point(0, 0);
            this.toolStrip6.Name = "toolStrip6";
            this.toolStrip6.Size = new System.Drawing.Size(1014, 25);
            this.toolStrip6.TabIndex = 14;
            this.toolStrip6.Text = "toolStrip6";
            this.toolStrip6.Visible = false;
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton9.Text = "刷新";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton10.Text = "样式";
            // 
            // TabItemUnLoadTimeOutAlarm
            // 
            this.TabItemUnLoadTimeOutAlarm.AttachedControl = this.superTabControlPanel6;
            this.TabItemUnLoadTimeOutAlarm.GlobalItem = false;
            this.TabItemUnLoadTimeOutAlarm.Name = "TabItemUnLoadTimeOutAlarm";
            this.TabItemUnLoadTimeOutAlarm.Text = "卸车不及时告警";
            this.TabItemUnLoadTimeOutAlarm.Click += new System.EventHandler(this.TabItemUnLoadTimeOutAlarm_Click);
            // 
            // superTabControlPanel5
            // 
            this.superTabControlPanel5.Controls.Add(this.dgvListTransportTimeOutAlarm);
            this.superTabControlPanel5.Controls.Add(this.toolStrip12);
            this.superTabControlPanel5.Controls.Add(this.toolStrip5);
            this.superTabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel5.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel5.Name = "superTabControlPanel5";
            this.superTabControlPanel5.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel5.TabIndex = 0;
            this.superTabControlPanel5.TabItem = this.TabItemTransportTimeOutAlarm;
            // 
            // dgvListTransportTimeOutAlarm
            // 
            this.dgvListTransportTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListTransportTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListTransportTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListTransportTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListTransportTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvListTransportTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListTransportTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListTransportTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListTransportTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListTransportTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListTransportTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvListTransportTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListTransportTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListTransportTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn61,
            this.dataGridViewTextBoxColumn62,
            this.dataGridViewTextBoxColumn63,
            this.Column2,
            this.dataGridViewTextBoxColumn79});
            this.dgvListTransportTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListTransportTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListTransportTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListTransportTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListTransportTimeOutAlarm.MultiSelect = false;
            this.dgvListTransportTimeOutAlarm.Name = "dgvListTransportTimeOutAlarm";
            this.dgvListTransportTimeOutAlarm.ReadOnly = true;
            this.dgvListTransportTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListTransportTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvListTransportTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListTransportTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListTransportTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvListTransportTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListTransportTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListTransportTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListTransportTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListTransportTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListTransportTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListTransportTimeOutAlarm.TabIndex = 18;
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn61.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            this.dataGridViewTextBoxColumn61.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn62.HeaderText = "申请部门";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            this.dataGridViewTextBoxColumn62.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn63
            // 
            this.dataGridViewTextBoxColumn63.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn63.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn63.Name = "dataGridViewTextBoxColumn63";
            this.dataGridViewTextBoxColumn63.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "计划到达时间";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn79
            // 
            this.dataGridViewTextBoxColumn79.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn79.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn79.Name = "dataGridViewTextBoxColumn79";
            this.dataGridViewTextBoxColumn79.ReadOnly = true;
            // 
            // toolStrip12
            // 
            this.toolStrip12.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip12.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxTransportTimeOutAlarm,
            this.btnYsTransportTimeOutAlarm});
            this.toolStrip12.Location = new System.Drawing.Point(0, 0);
            this.toolStrip12.Name = "toolStrip12";
            this.toolStrip12.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip12.TabIndex = 17;
            this.toolStrip12.Text = "toolStrip12";
            // 
            // btnSxTransportTimeOutAlarm
            // 
            this.btnSxTransportTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxTransportTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxTransportTimeOutAlarm.Name = "btnSxTransportTimeOutAlarm";
            this.btnSxTransportTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxTransportTimeOutAlarm.Text = "刷新";
            this.btnSxTransportTimeOutAlarm.Click += new System.EventHandler(this.btnSxTransportTimeOutAlarm_Click);
            // 
            // btnYsTransportTimeOutAlarm
            // 
            this.btnYsTransportTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsTransportTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsTransportTimeOutAlarm.Name = "btnYsTransportTimeOutAlarm";
            this.btnYsTransportTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsTransportTimeOutAlarm.Text = "样式";
            this.btnYsTransportTimeOutAlarm.Click += new System.EventHandler(this.btnYsTransportTimeOutAlarm_Click);
            // 
            // toolStrip5
            // 
            this.toolStrip5.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton7,
            this.toolStripButton8});
            this.toolStrip5.Location = new System.Drawing.Point(0, 0);
            this.toolStrip5.Name = "toolStrip5";
            this.toolStrip5.Size = new System.Drawing.Size(1094, 25);
            this.toolStrip5.TabIndex = 14;
            this.toolStrip5.Text = "toolStrip5";
            this.toolStrip5.Visible = false;
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton7.Text = "刷新";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton8.Text = "样式";
            // 
            // TabItemTransportTimeOutAlarm
            // 
            this.TabItemTransportTimeOutAlarm.AttachedControl = this.superTabControlPanel5;
            this.TabItemTransportTimeOutAlarm.GlobalItem = false;
            this.TabItemTransportTimeOutAlarm.Name = "TabItemTransportTimeOutAlarm";
            this.TabItemTransportTimeOutAlarm.Text = "未按时运送告警";
            this.TabItemTransportTimeOutAlarm.Click += new System.EventHandler(this.TabItemTransportTimeOutAlarm_Click);
            // 
            // superTabControlPanel4
            // 
            this.superTabControlPanel4.Controls.Add(this.dgvListLoadTimeOutAlarm);
            this.superTabControlPanel4.Controls.Add(this.toolStrip4);
            this.superTabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel4.Name = "superTabControlPanel4";
            this.superTabControlPanel4.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel4.TabIndex = 0;
            this.superTabControlPanel4.TabItem = this.TabItemLoadTimeOutAlarm;
            // 
            // dgvListLoadTimeOutAlarm
            // 
            this.dgvListLoadTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListLoadTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListLoadTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListLoadTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListLoadTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvListLoadTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListLoadTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListLoadTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListLoadTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListLoadTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListLoadTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvListLoadTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListLoadTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListLoadTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.Column3,
            this.dataGridViewTextBoxColumn13});
            this.dgvListLoadTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListLoadTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListLoadTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListLoadTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListLoadTimeOutAlarm.MultiSelect = false;
            this.dgvListLoadTimeOutAlarm.Name = "dgvListLoadTimeOutAlarm";
            this.dgvListLoadTimeOutAlarm.ReadOnly = true;
            this.dgvListLoadTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle31.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListLoadTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvListLoadTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListLoadTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListLoadTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvListLoadTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListLoadTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListLoadTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListLoadTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListLoadTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListLoadTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListLoadTimeOutAlarm.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn10.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn11.HeaderText = "申请部门";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn12.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "计划装车部门";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn13.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // toolStrip4
            // 
            this.toolStrip4.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxLoadTimeOutAlarm,
            this.btnYsLoadTimeOutAlarm});
            this.toolStrip4.Location = new System.Drawing.Point(0, 0);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip4.TabIndex = 14;
            this.toolStrip4.Text = "toolStrip4";
            // 
            // btnSxLoadTimeOutAlarm
            // 
            this.btnSxLoadTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxLoadTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxLoadTimeOutAlarm.Name = "btnSxLoadTimeOutAlarm";
            this.btnSxLoadTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxLoadTimeOutAlarm.Text = "刷新";
            this.btnSxLoadTimeOutAlarm.Click += new System.EventHandler(this.btnSxLoadTimeOutAlarm_Click);
            // 
            // btnYsLoadTimeOutAlarm
            // 
            this.btnYsLoadTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsLoadTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsLoadTimeOutAlarm.Name = "btnYsLoadTimeOutAlarm";
            this.btnYsLoadTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsLoadTimeOutAlarm.Text = "样式";
            this.btnYsLoadTimeOutAlarm.Click += new System.EventHandler(this.btnYsLoadTimeOutAlarm_Click);
            // 
            // TabItemLoadTimeOutAlarm
            // 
            this.TabItemLoadTimeOutAlarm.AttachedControl = this.superTabControlPanel4;
            this.TabItemLoadTimeOutAlarm.GlobalItem = false;
            this.TabItemLoadTimeOutAlarm.Name = "TabItemLoadTimeOutAlarm";
            this.TabItemLoadTimeOutAlarm.Text = "装车不及时告警";
            this.TabItemLoadTimeOutAlarm.Click += new System.EventHandler(this.TabItemLoadTimeOutAlarm_Click);
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.dgvListGiveTimeOutAlarm);
            this.superTabControlPanel3.Controls.Add(this.toolStrip18);
            this.superTabControlPanel3.Controls.Add(this.toolStrip2);
            this.superTabControlPanel3.Controls.Add(this.toolStrip3);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            this.superTabControlPanel3.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel3.TabIndex = 0;
            this.superTabControlPanel3.TabItem = this.TabItemGiveTimeOutAlarm;
            // 
            // dgvListGiveTimeOutAlarm
            // 
            this.dgvListGiveTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListGiveTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListGiveTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListGiveTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListGiveTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvListGiveTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListGiveTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListGiveTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListGiveTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListGiveTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListGiveTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvListGiveTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListGiveTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListGiveTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.Column6,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dgvListGiveTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListGiveTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListGiveTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListGiveTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListGiveTimeOutAlarm.MultiSelect = false;
            this.dgvListGiveTimeOutAlarm.Name = "dgvListGiveTimeOutAlarm";
            this.dgvListGiveTimeOutAlarm.ReadOnly = true;
            this.dgvListGiveTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle35.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListGiveTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvListGiveTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListGiveTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListGiveTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvListGiveTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListGiveTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListGiveTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListGiveTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListGiveTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListGiveTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListGiveTimeOutAlarm.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn2.HeaderText = "计划编号";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "申请部门";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn3.HeaderText = "目的地";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn7.HeaderText = "计划供车部门";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn8.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // toolStrip18
            // 
            this.toolStrip18.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip18.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxGcAlarm,
            this.btnYsGcAlarm});
            this.toolStrip18.Location = new System.Drawing.Point(0, 0);
            this.toolStrip18.Name = "toolStrip18";
            this.toolStrip18.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip18.TabIndex = 17;
            this.toolStrip18.Text = "toolStrip18";
            // 
            // btnSxGcAlarm
            // 
            this.btnSxGcAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxGcAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxGcAlarm.Name = "btnSxGcAlarm";
            this.btnSxGcAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxGcAlarm.Text = "刷新";
            this.btnSxGcAlarm.Click += new System.EventHandler(this.btnSxGcAlarm_Click);
            // 
            // btnYsGcAlarm
            // 
            this.btnYsGcAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsGcAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsGcAlarm.Name = "btnYsGcAlarm";
            this.btnYsGcAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsGcAlarm.Text = "样式";
            this.btnYsGcAlarm.Click += new System.EventHandler(this.btnYsGcAlarm_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxGiveTimeOutAlarm,
            this.btnYsGiveTimeOutAlarm});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1094, 25);
            this.toolStrip2.TabIndex = 16;
            this.toolStrip2.Text = "toolStrip2";
            this.toolStrip2.Visible = false;
            // 
            // btnSxGiveTimeOutAlarm
            // 
            this.btnSxGiveTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxGiveTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxGiveTimeOutAlarm.Name = "btnSxGiveTimeOutAlarm";
            this.btnSxGiveTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxGiveTimeOutAlarm.Text = "刷新";
            // 
            // btnYsGiveTimeOutAlarm
            // 
            this.btnYsGiveTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsGiveTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsGiveTimeOutAlarm.Name = "btnYsGiveTimeOutAlarm";
            this.btnYsGiveTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsGiveTimeOutAlarm.Text = "样式";
            // 
            // toolStrip3
            // 
            this.toolStrip3.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip3.Location = new System.Drawing.Point(0, 0);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(1014, 25);
            this.toolStrip3.TabIndex = 14;
            this.toolStrip3.Text = "toolStrip3";
            this.toolStrip3.Visible = false;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton1.Text = "刷新";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton2.Text = "样式";
            // 
            // TabItemGiveTimeOutAlarm
            // 
            this.TabItemGiveTimeOutAlarm.AttachedControl = this.superTabControlPanel3;
            this.TabItemGiveTimeOutAlarm.GlobalItem = false;
            this.TabItemGiveTimeOutAlarm.Name = "TabItemGiveTimeOutAlarm";
            this.TabItemGiveTimeOutAlarm.Text = "供车不及时告警";
            this.TabItemGiveTimeOutAlarm.Click += new System.EventHandler(this.TabItemGiveTimeOutAlarm_Click);
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.dgvListScrapTimeOutAlarm);
            this.superTabControlPanel2.Controls.Add(this.toolStrip19);
            this.superTabControlPanel2.Controls.Add(this.toolStrip11);
            this.superTabControlPanel2.Controls.Add(this.statusStrip2);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(1166, 523);
            this.superTabControlPanel2.TabIndex = 2;
            this.superTabControlPanel2.TabItem = this.TabItemScrapTimeOutAlarm;
            // 
            // dgvListScrapTimeOutAlarm
            // 
            this.dgvListScrapTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListScrapTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListScrapTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListScrapTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListScrapTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvListScrapTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListScrapTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListScrapTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListScrapTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListScrapTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle38.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListScrapTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle38;
            this.dgvListScrapTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListScrapTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListScrapTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn58,
            this.dataGridViewTextBoxColumn59,
            this.Column5,
            this.dataGridViewTextBoxColumn60});
            this.dgvListScrapTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListScrapTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListScrapTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListScrapTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListScrapTimeOutAlarm.MultiSelect = false;
            this.dgvListScrapTimeOutAlarm.Name = "dgvListScrapTimeOutAlarm";
            this.dgvListScrapTimeOutAlarm.ReadOnly = true;
            this.dgvListScrapTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle39.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListScrapTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvListScrapTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListScrapTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListScrapTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvListScrapTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListScrapTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListScrapTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListScrapTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListScrapTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListScrapTimeOutAlarm.Size = new System.Drawing.Size(1166, 498);
            this.dgvListScrapTimeOutAlarm.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn58.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            this.dataGridViewTextBoxColumn58.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn59.HeaderText = "车辆名称";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            this.dataGridViewTextBoxColumn59.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "计划报废时间";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.FillWeight = 152.2843F;
            this.dataGridViewTextBoxColumn60.HeaderText = "告警开始时间";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            this.dataGridViewTextBoxColumn60.ReadOnly = true;
            // 
            // toolStrip19
            // 
            this.toolStrip19.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip19.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxCq,
            this.btnYsCq});
            this.toolStrip19.Location = new System.Drawing.Point(0, 0);
            this.toolStrip19.Name = "toolStrip19";
            this.toolStrip19.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip19.TabIndex = 16;
            this.toolStrip19.Text = "toolStrip19";
            // 
            // btnSxCq
            // 
            this.btnSxCq.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxCq.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxCq.Name = "btnSxCq";
            this.btnSxCq.Size = new System.Drawing.Size(52, 22);
            this.btnSxCq.Text = "刷新";
            this.btnSxCq.Click += new System.EventHandler(this.btnSxCq_Click);
            // 
            // btnYsCq
            // 
            this.btnYsCq.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsCq.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsCq.Name = "btnYsCq";
            this.btnYsCq.Size = new System.Drawing.Size(52, 22);
            this.btnYsCq.Text = "样式";
            this.btnYsCq.Click += new System.EventHandler(this.btnYsCq_Click);
            // 
            // toolStrip11
            // 
            this.toolStrip11.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip11.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSxScrapTimeOutAlarm,
            this.btnYsScrapTimeOutAlarm});
            this.toolStrip11.Location = new System.Drawing.Point(0, 0);
            this.toolStrip11.Name = "toolStrip11";
            this.toolStrip11.Size = new System.Drawing.Size(1094, 25);
            this.toolStrip11.TabIndex = 14;
            this.toolStrip11.Text = "toolStrip11";
            this.toolStrip11.Visible = false;
            // 
            // btnSxScrapTimeOutAlarm
            // 
            this.btnSxScrapTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnSxScrapTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSxScrapTimeOutAlarm.Name = "btnSxScrapTimeOutAlarm";
            this.btnSxScrapTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnSxScrapTimeOutAlarm.Text = "刷新";
            // 
            // btnYsScrapTimeOutAlarm
            // 
            this.btnYsScrapTimeOutAlarm.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnYsScrapTimeOutAlarm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnYsScrapTimeOutAlarm.Name = "btnYsScrapTimeOutAlarm";
            this.btnYsScrapTimeOutAlarm.Size = new System.Drawing.Size(52, 22);
            this.btnYsScrapTimeOutAlarm.Text = "样式";
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip2.Location = new System.Drawing.Point(0, 470);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(1014, 22);
            this.statusStrip2.TabIndex = 5;
            this.statusStrip2.Text = "statusStrip2";
            this.statusStrip2.Visible = false;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // TabItemScrapTimeOutAlarm
            // 
            this.TabItemScrapTimeOutAlarm.AttachedControl = this.superTabControlPanel2;
            this.TabItemScrapTimeOutAlarm.GlobalItem = false;
            this.TabItemScrapTimeOutAlarm.Name = "TabItemScrapTimeOutAlarm";
            this.TabItemScrapTimeOutAlarm.Text = "报废超期告警";
            this.TabItemScrapTimeOutAlarm.Click += new System.EventHandler(this.TabItemScrapTimeOutAlarm_Click);
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.dgvListMaintainTimeOutAlarm);
            this.superTabControlPanel1.Controls.Add(this.toolStrip1);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 28);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(1166, 495);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.TabItemMaintainTimeOutAlarm;
            // 
            // dgvListMaintainTimeOutAlarm
            // 
            this.dgvListMaintainTimeOutAlarm.AllowUserToAddRows = false;
            this.dgvListMaintainTimeOutAlarm.AllowUserToDeleteRows = false;
            this.dgvListMaintainTimeOutAlarm.AllowUserToResizeRows = false;
            this.dgvListMaintainTimeOutAlarm.AlternatingRowsBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListMaintainTimeOutAlarm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvListMaintainTimeOutAlarm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListMaintainTimeOutAlarm.BackgroundColor = System.Drawing.Color.White;
            this.dgvListMaintainTimeOutAlarm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListMaintainTimeOutAlarm.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListMaintainTimeOutAlarm.ColumnHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(232)))), ((int)(((byte)(243)))));
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(245)))), ((int)(((byte)(248)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListMaintainTimeOutAlarm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvListMaintainTimeOutAlarm.ColumnHeadersHeight = 35;
            this.dgvListMaintainTimeOutAlarm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListMaintainTimeOutAlarm.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.vc_Name,
            this.Column8,
            this.Column9,
            this.Column4});
            this.dgvListMaintainTimeOutAlarm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListMaintainTimeOutAlarm.EnableHeadersVisualStyles = false;
            this.dgvListMaintainTimeOutAlarm.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvListMaintainTimeOutAlarm.Location = new System.Drawing.Point(0, 25);
            this.dgvListMaintainTimeOutAlarm.MultiSelect = false;
            this.dgvListMaintainTimeOutAlarm.Name = "dgvListMaintainTimeOutAlarm";
            this.dgvListMaintainTimeOutAlarm.ReadOnly = true;
            this.dgvListMaintainTimeOutAlarm.RowHeadersDefaultBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(219)))), ((int)(((byte)(231)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListMaintainTimeOutAlarm.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvListMaintainTimeOutAlarm.RowHeadersVisible = false;
            this.dgvListMaintainTimeOutAlarm.RowsDefaultBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListMaintainTimeOutAlarm.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvListMaintainTimeOutAlarm.RowsDefaultSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(41)))), ((int)(((byte)(80)))));
            this.dgvListMaintainTimeOutAlarm.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(232)))), ((int)(((byte)(249)))));
            this.dgvListMaintainTimeOutAlarm.RowTemplate.Height = 35;
            this.dgvListMaintainTimeOutAlarm.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(211)))), ((int)(((byte)(128)))));
            this.dgvListMaintainTimeOutAlarm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListMaintainTimeOutAlarm.Size = new System.Drawing.Size(1166, 470);
            this.dgvListMaintainTimeOutAlarm.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 89.54315F;
            this.dataGridViewTextBoxColumn1.HeaderText = "车辆编号";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // vc_Name
            // 
            this.vc_Name.FillWeight = 89.54315F;
            this.vc_Name.HeaderText = "车辆名称";
            this.vc_Name.Name = "vc_Name";
            this.vc_Name.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "维护周期(天)";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "最后检修时间";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.FillWeight = 152.2843F;
            this.Column4.HeaderText = "告警开始时间";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnRefresh,
            this.btnStyle});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1166, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Image = global::VehicleTransportClient.Properties.Resources.Refresh;
            this.btnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(52, 22);
            this.btnRefresh.Text = "刷新";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnStyle
            // 
            this.btnStyle.Image = global::VehicleTransportClient.Properties.Resources.GridStyle;
            this.btnStyle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnStyle.Name = "btnStyle";
            this.btnStyle.Size = new System.Drawing.Size(52, 22);
            this.btnStyle.Text = "样式";
            this.btnStyle.Click += new System.EventHandler(this.btnStyle_Click);
            // 
            // TabItemMaintainTimeOutAlarm
            // 
            this.TabItemMaintainTimeOutAlarm.AttachedControl = this.superTabControlPanel1;
            this.TabItemMaintainTimeOutAlarm.GlobalItem = false;
            this.TabItemMaintainTimeOutAlarm.Name = "TabItemMaintainTimeOutAlarm";
            this.TabItemMaintainTimeOutAlarm.Text = "检修超期告警";
            this.TabItemMaintainTimeOutAlarm.Click += new System.EventHandler(this.TabItemMaintainTimeOutAlarm_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblCount});
            this.statusStrip1.Location = new System.Drawing.Point(0, 501);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1166, 22);
            this.statusStrip1.TabIndex = 17;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblCount
            // 
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(0, 17);
            // 
            // FormCurrentAlarm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 552);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "FormCurrentAlarm";
            this.NeedMax = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "密码修改";
            this.panelWorkArea.ResumeLayout(false);
            this.panelWorkArea.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TabControlCurrentAlarm)).EndInit();
            this.TabControlCurrentAlarm.ResumeLayout(false);
            this.superTabControlPanel14.ResumeLayout(false);
            this.superTabControlPanel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListNoChanageStateAlarm)).EndInit();
            this.toolStrip17.ResumeLayout(false);
            this.toolStrip17.PerformLayout();
            this.superTabControlPanel13.ResumeLayout(false);
            this.superTabControlPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListRunDerictionAlarm)).EndInit();
            this.toolStrip16.ResumeLayout(false);
            this.toolStrip16.PerformLayout();
            this.superTabControlPanel12.ResumeLayout(false);
            this.superTabControlPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListNoUseAlarm)).EndInit();
            this.toolStrip15.ResumeLayout(false);
            this.toolStrip15.PerformLayout();
            this.superTabControlPanel10.ResumeLayout(false);
            this.superTabControlPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListBackTimeOutAlarm)).EndInit();
            this.toolStrip14.ResumeLayout(false);
            this.toolStrip14.PerformLayout();
            this.toolStrip10.ResumeLayout(false);
            this.toolStrip10.PerformLayout();
            this.superTabControlPanel6.ResumeLayout(false);
            this.superTabControlPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListUnLoadTimeOutAlarm)).EndInit();
            this.toolStrip13.ResumeLayout(false);
            this.toolStrip13.PerformLayout();
            this.toolStrip6.ResumeLayout(false);
            this.toolStrip6.PerformLayout();
            this.superTabControlPanel5.ResumeLayout(false);
            this.superTabControlPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListTransportTimeOutAlarm)).EndInit();
            this.toolStrip12.ResumeLayout(false);
            this.toolStrip12.PerformLayout();
            this.toolStrip5.ResumeLayout(false);
            this.toolStrip5.PerformLayout();
            this.superTabControlPanel4.ResumeLayout(false);
            this.superTabControlPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListLoadTimeOutAlarm)).EndInit();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.superTabControlPanel3.ResumeLayout(false);
            this.superTabControlPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListGiveTimeOutAlarm)).EndInit();
            this.toolStrip18.ResumeLayout(false);
            this.toolStrip18.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.superTabControlPanel2.ResumeLayout(false);
            this.superTabControlPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListScrapTimeOutAlarm)).EndInit();
            this.toolStrip19.ResumeLayout(false);
            this.toolStrip19.PerformLayout();
            this.toolStrip11.ResumeLayout(false);
            this.toolStrip11.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.superTabControlPanel1.ResumeLayout(false);
            this.superTabControlPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListMaintainTimeOutAlarm)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.BalloonTip balloonTip1;
        private DevComponents.DotNetBar.SuperTabControl TabControlCurrentAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel13;
        private Tools.DataGridViewEx dgvListRunDerictionAlarm;
        private System.Windows.Forms.ToolStrip toolStrip16;
        private System.Windows.Forms.ToolStripButton btnSxRunDerictionAlarm;
        private System.Windows.Forms.ToolStripButton btnYsRunDerictionAlarm;
        private DevComponents.DotNetBar.SuperTabItem TabItemRunDerictionAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private Tools.DataGridViewEx dgvListMaintainTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnRefresh;
        private System.Windows.Forms.ToolStripButton btnStyle;
        private DevComponents.DotNetBar.SuperTabItem TabItemMaintainTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private Tools.DataGridViewEx dgvListScrapTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip19;
        private System.Windows.Forms.ToolStripButton btnSxCq;
        private System.Windows.Forms.ToolStripButton btnYsCq;
        private System.Windows.Forms.ToolStrip toolStrip11;
        private System.Windows.Forms.ToolStripButton btnSxScrapTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsScrapTimeOutAlarm;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private DevComponents.DotNetBar.SuperTabItem TabItemScrapTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3;
        private Tools.DataGridViewEx dgvListGiveTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip18;
        private System.Windows.Forms.ToolStripButton btnSxGcAlarm;
        private System.Windows.Forms.ToolStripButton btnYsGcAlarm;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton btnSxGiveTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsGiveTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private DevComponents.DotNetBar.SuperTabItem TabItemGiveTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel14;
        private Tools.DataGridViewEx dgvListNoChanageStateAlarm;
        private System.Windows.Forms.ToolStrip toolStrip17;
        private System.Windows.Forms.ToolStripButton btnReNoChanageStateAlarm;
        private System.Windows.Forms.ToolStripButton btnNoChanageStateAlarm;
        private DevComponents.DotNetBar.SuperTabItem TabItemNoChanageStateAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel12;
        private Tools.DataGridViewEx dgvListNoUseAlarm;
        private System.Windows.Forms.ToolStrip toolStrip15;
        private System.Windows.Forms.ToolStripButton btnSxNoUseAlarm;
        private System.Windows.Forms.ToolStripButton btnYsNoUseAlarm;
        private DevComponents.DotNetBar.SuperTabItem TabItemNoUseAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel10;
        private Tools.DataGridViewEx dgvListBackTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip14;
        private System.Windows.Forms.ToolStripButton btnSxBackTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsBackTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip10;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private DevComponents.DotNetBar.SuperTabItem TabItemBackTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel6;
        private Tools.DataGridViewEx dgvListUnLoadTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip13;
        private System.Windows.Forms.ToolStripButton btnSxUnLoadTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsUnLoadTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip6;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private DevComponents.DotNetBar.SuperTabItem TabItemUnLoadTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel5;
        private Tools.DataGridViewEx dgvListTransportTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip12;
        private System.Windows.Forms.ToolStripButton btnSxTransportTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsTransportTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip5;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private DevComponents.DotNetBar.SuperTabItem TabItemTransportTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel4;
        private Tools.DataGridViewEx dgvListLoadTimeOutAlarm;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripButton btnSxLoadTimeOutAlarm;
        private System.Windows.Forms.ToolStripButton btnYsLoadTimeOutAlarm;
        private DevComponents.DotNetBar.SuperTabItem TabItemLoadTimeOutAlarm;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn63;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn79;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn80;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn69;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn81;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn76;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn77;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn78;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn84;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn73;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn74;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn75;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn83;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn71;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn72;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn82;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn vc_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}