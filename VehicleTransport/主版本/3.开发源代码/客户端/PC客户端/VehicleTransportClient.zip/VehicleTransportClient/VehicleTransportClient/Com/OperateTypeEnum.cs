﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VehicleTransportClient.Com
{
    public enum OperateTypeEnum
    {
        Add=0,
        Edit=1
    }
}
