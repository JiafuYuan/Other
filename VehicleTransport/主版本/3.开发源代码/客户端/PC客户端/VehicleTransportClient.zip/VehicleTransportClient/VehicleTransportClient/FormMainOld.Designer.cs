﻿namespace VehicleTransportClient
{
    partial class FormMainOld : Common.frmBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMainOld));
            this.panel1 = new System.Windows.Forms.Panel();
            this.labcheckstate = new DevComponents.DotNetBar.LabelX();
            this.btnclose = new DevComponents.DotNetBar.ButtonX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.btnquery = new DevComponents.DotNetBar.ButtonX();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.btnMap = new DevComponents.DotNetBar.ButtonX();
            this.btnCheckMgr = new DevComponents.DotNetBar.ButtonX();
            this.btnApply = new DevComponents.DotNetBar.ButtonX();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.lbdbstate = new DevComponents.DotNetBar.LabelX();
            this.lbstate = new DevComponents.DotNetBar.LabelX();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem9 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem10 = new DevComponents.DotNetBar.ButtonItem();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panfull = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panRight = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.lblNav = new DevComponents.DotNetBar.LabelX();
            this.panelleft = new System.Windows.Forms.Panel();
            this.panelLeftBar = new System.Windows.Forms.Panel();
            this.panelConfig = new DevComponents.DotNetBar.ExpandablePanel();
            this.itemPanel5 = new DevComponents.DotNetBar.ItemPanel();
            this.btnUserManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnRuleManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnPasswordEdit = new DevComponents.DotNetBar.ButtonItem();
            this.btnAlarmSet = new DevComponents.DotNetBar.ButtonItem();
            this.btnSystemLog = new DevComponents.DotNetBar.ButtonItem();
            this.panelAlarm = new DevComponents.DotNetBar.ExpandablePanel();
            this.itemPanel4 = new DevComponents.DotNetBar.ItemPanel();
            this.btnMaintainTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnScrapTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnGiveTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnLoadTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnTransportTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnUnLoadTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnBackTimeOutAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnNoUseAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnRunDerictionAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnNoChanageStateAlarm = new DevComponents.DotNetBar.ButtonItem();
            this.btnSendMessage = new DevComponents.DotNetBar.ButtonItem();
            this.panelAnaly = new DevComponents.DotNetBar.ExpandablePanel();
            this.itemPanel1 = new DevComponents.DotNetBar.ItemPanel();
            this.btnVehicleDept = new DevComponents.DotNetBar.ButtonItem();
            this.btnVehicleMonth = new DevComponents.DotNetBar.ButtonItem();
            this.btnMaterielReport = new DevComponents.DotNetBar.ButtonItem();
            this.btnNoUseMonthReport = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem7 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem8 = new DevComponents.DotNetBar.ButtonItem();
            this.panelBaseinfo = new DevComponents.DotNetBar.ExpandablePanel();
            this.itemPanel2 = new DevComponents.DotNetBar.ItemPanel();
            this.btnPersonManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnDeptManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnAreaManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnStationManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnWifiStation = new DevComponents.DotNetBar.ButtonItem();
            this.btnCarTypeManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnCarManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnVehicleMaintain = new DevComponents.DotNetBar.ButtonItem();
            this.btnCarScraped = new DevComponents.DotNetBar.ButtonItem();
            this.btnPDAManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnCardManage = new DevComponents.DotNetBar.ButtonItem();
            this.btnMaterielType = new DevComponents.DotNetBar.ButtonItem();
            this.panelFlow = new DevComponents.DotNetBar.ExpandablePanel();
            this.itemPanel3 = new DevComponents.DotNetBar.ItemPanel();
            this.btnmyapply = new DevComponents.DotNetBar.ButtonItem();
            this.btnCheck = new DevComponents.DotNetBar.ButtonItem();
            this.btnSupply = new DevComponents.DotNetBar.ButtonItem();
            this.btnloadcar = new DevComponents.DotNetBar.ButtonItem();
            this.btnTransfer = new DevComponents.DotNetBar.ButtonItem();
            this.btnunload = new DevComponents.DotNetBar.ButtonItem();
            this.btnbackcar = new DevComponents.DotNetBar.ButtonItem();
            this.panel8 = new System.Windows.Forms.Panel();
            this.labuser = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDeptMaterielTypeReport = new DevComponents.DotNetBar.ButtonItem();
            this.panelWorkArea.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panfull.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelleft.SuspendLayout();
            this.panelLeftBar.SuspendLayout();
            this.panelConfig.SuspendLayout();
            this.panelAlarm.SuspendLayout();
            this.panelAnaly.SuspendLayout();
            this.panelBaseinfo.SuspendLayout();
            this.panelFlow.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelWorkArea
            // 
            this.panelWorkArea.Controls.Add(this.panfull);
            this.panelWorkArea.Controls.Add(this.panel5);
            this.panelWorkArea.Controls.Add(this.panel3);
            this.panelWorkArea.Controls.Add(this.panel1);
            this.panelWorkArea.Size = new System.Drawing.Size(1022, 882);
            // 
            // panelTitle
            // 
            this.panelTitle.Location = new System.Drawing.Point(239, 0);
            this.panelTitle.Size = new System.Drawing.Size(691, 28);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.labcheckstate);
            this.panel1.Controls.Add(this.btnclose);
            this.panel1.Controls.Add(this.labelX3);
            this.panel1.Controls.Add(this.labelX2);
            this.panel1.Controls.Add(this.labelX1);
            this.panel1.Controls.Add(this.btnquery);
            this.panel1.Controls.Add(this.buttonX4);
            this.panel1.Controls.Add(this.btnMap);
            this.panel1.Controls.Add(this.btnCheckMgr);
            this.panel1.Controls.Add(this.btnApply);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1022, 87);
            this.panel1.TabIndex = 0;
            // 
            // labcheckstate
            // 
            this.labcheckstate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.labcheckstate.BackgroundStyle.Class = "";
            this.labcheckstate.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labcheckstate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labcheckstate.Location = new System.Drawing.Point(855, 60);
            this.labcheckstate.Name = "labcheckstate";
            this.labcheckstate.Size = new System.Drawing.Size(75, 23);
            this.labcheckstate.TabIndex = 10;
            this.labcheckstate.Text = "待审核：0";
            this.labcheckstate.Click += new System.EventHandler(this.labcheckstate_Click);
            // 
            // btnclose
            // 
            this.btnclose.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnclose.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.btnclose.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.btnclose.HoverImage = global::VehicleTransportClient.Properties.Resources.退出系统2;
            this.btnclose.Image = global::VehicleTransportClient.Properties.Resources.退出系统;
            this.btnclose.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnclose.Location = new System.Drawing.Point(480, 3);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(60, 80);
            this.btnclose.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.btnclose.TabIndex = 9;
            this.btnclose.Text = "退出系统";
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // labelX3
            // 
            this.labelX3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(944, 44);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(75, 23);
            this.labelX3.TabIndex = 7;
            this.labelX3.Text = "星期四";
            // 
            // labelX2
            // 
            this.labelX2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(944, 24);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(75, 23);
            this.labelX2.TabIndex = 6;
            this.labelX2.Text = "11：12";
            // 
            // labelX1
            // 
            this.labelX1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(930, 6);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(75, 23);
            this.labelX1.TabIndex = 5;
            this.labelX1.Text = " 2014-08-08";
            // 
            // btnquery
            // 
            this.btnquery.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnquery.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.btnquery.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.btnquery.HoverImage = global::VehicleTransportClient.Properties.Resources.状态查询2;
            this.btnquery.Image = global::VehicleTransportClient.Properties.Resources.状态查询;
            this.btnquery.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnquery.Location = new System.Drawing.Point(390, 3);
            this.btnquery.Name = "btnquery";
            this.btnquery.Size = new System.Drawing.Size(60, 80);
            this.btnquery.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.btnquery.TabIndex = 4;
            this.btnquery.Text = "状态查询";
            this.btnquery.Click += new System.EventHandler(this.buttonX5_Click);
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.buttonX4.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.buttonX4.HoverImage = global::VehicleTransportClient.Properties.Resources.锁定系统2;
            this.buttonX4.Image = global::VehicleTransportClient.Properties.Resources.锁定系统;
            this.buttonX4.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonX4.Location = new System.Drawing.Point(300, 3);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(60, 80);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.buttonX4.TabIndex = 3;
            this.buttonX4.Text = "锁定";
            this.buttonX4.Click += new System.EventHandler(this.buttonX4_Click);
            // 
            // btnMap
            // 
            this.btnMap.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnMap.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.btnMap.FocusCuesEnabled = false;
            this.btnMap.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.btnMap.HoverImage = global::VehicleTransportClient.Properties.Resources.地图2;
            this.btnMap.Image = global::VehicleTransportClient.Properties.Resources.地图;
            this.btnMap.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnMap.Location = new System.Drawing.Point(210, 3);
            this.btnMap.Name = "btnMap";
            this.btnMap.Size = new System.Drawing.Size(60, 80);
            this.btnMap.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.btnMap.TabIndex = 2;
            this.btnMap.Text = "地图";
            this.btnMap.Click += new System.EventHandler(this.btnMap_Click);
            // 
            // btnCheckMgr
            // 
            this.btnCheckMgr.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnCheckMgr.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.btnCheckMgr.FocusCuesEnabled = false;
            this.btnCheckMgr.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.btnCheckMgr.HoverImage = global::VehicleTransportClient.Properties.Resources.审核2;
            this.btnCheckMgr.Image = global::VehicleTransportClient.Properties.Resources.审核;
            this.btnCheckMgr.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnCheckMgr.Location = new System.Drawing.Point(120, 3);
            this.btnCheckMgr.Name = "btnCheckMgr";
            this.btnCheckMgr.Size = new System.Drawing.Size(60, 80);
            this.btnCheckMgr.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.btnCheckMgr.TabIndex = 1;
            this.btnCheckMgr.Text = "审核";
            this.btnCheckMgr.Click += new System.EventHandler(this.btnReview_Click);
            // 
            // btnApply
            // 
            this.btnApply.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnApply.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.btnApply.FocusCuesEnabled = false;
            this.btnApply.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.btnApply.HoverImage = global::VehicleTransportClient.Properties.Resources.申请2;
            this.btnApply.Image = global::VehicleTransportClient.Properties.Resources.申请;
            this.btnApply.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnApply.Location = new System.Drawing.Point(30, 3);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(60, 80);
            this.btnApply.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.btnApply.TabIndex = 0;
            this.btnApply.Text = "申请";
            this.btnApply.Click += new System.EventHandler(this.btnapply_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.labelX9);
            this.panel3.Controls.Add(this.labelX8);
            this.panel3.Controls.Add(this.lbdbstate);
            this.panel3.Controls.Add(this.lbstate);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 858);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1022, 24);
            this.panel3.TabIndex = 1;
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Location = new System.Drawing.Point(462, 3);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(197, 23);
            this.labelX9.TabIndex = 13;
            this.labelX9.Text = "南京北路自动化系统有限责任公司";
            // 
            // labelX8
            // 
            this.labelX8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.ForeColor = System.Drawing.Color.Red;
            this.labelX8.Location = new System.Drawing.Point(946, 2);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(74, 18);
            this.labelX8.TabIndex = 12;
            this.labelX8.Text = "告警（5）";
            this.labelX8.Click += new System.EventHandler(this.labelX8_Click);
            // 
            // lbdbstate
            // 
            // 
            // 
            // 
            this.lbdbstate.BackgroundStyle.Class = "";
            this.lbdbstate.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lbdbstate.Location = new System.Drawing.Point(159, 3);
            this.lbdbstate.Name = "lbdbstate";
            this.lbdbstate.Size = new System.Drawing.Size(135, 23);
            this.lbdbstate.TabIndex = 11;
            this.lbdbstate.Text = "数据库连接状态：成功";
            // 
            // lbstate
            // 
            // 
            // 
            // 
            this.lbstate.BackgroundStyle.Class = "";
            this.lbstate.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lbstate.Location = new System.Drawing.Point(10, 3);
            this.lbstate.Name = "lbstate";
            this.lbstate.Size = new System.Drawing.Size(135, 23);
            this.lbstate.TabIndex = 10;
            this.lbstate.Text = "服务器连接状态：成功";
            // 
            // buttonItem1
            // 
            this.buttonItem1.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.buttonItem1.HotFontUnderline = true;
            this.buttonItem1.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.buttonItem1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.Text = "Wifi基站管理";
            // 
            // buttonItem3
            // 
            this.buttonItem3.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonItem3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.buttonItem3.HotFontUnderline = true;
            this.buttonItem3.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.buttonItem3.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.Text = "车辆闲置月报表";
            // 
            // buttonItem4
            // 
            this.buttonItem4.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonItem4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.buttonItem4.HotFontUnderline = true;
            this.buttonItem4.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.buttonItem4.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.buttonItem4.Name = "buttonItem4";
            this.buttonItem4.Text = "物料使用月报表";
            // 
            // buttonItem9
            // 
            this.buttonItem9.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonItem9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.buttonItem9.HotFontUnderline = true;
            this.buttonItem9.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.buttonItem9.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.buttonItem9.Name = "buttonItem9";
            this.buttonItem9.Text = "车辆调度计划";
            // 
            // buttonItem10
            // 
            this.buttonItem10.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonItem10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.buttonItem10.HotFontUnderline = true;
            this.buttonItem10.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.buttonItem10.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.buttonItem10.Name = "buttonItem10";
            this.buttonItem10.Text = "车辆临时调度计划";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(127)))), ((int)(((byte)(163)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 87);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1022, 3);
            this.panel5.TabIndex = 4;
            // 
            // panfull
            // 
            this.panfull.BackColor = System.Drawing.Color.Transparent;
            this.panfull.Controls.Add(this.panel6);
            this.panfull.Controls.Add(this.panelleft);
            this.panfull.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panfull.Location = new System.Drawing.Point(0, 90);
            this.panfull.Name = "panfull";
            this.panfull.Size = new System.Drawing.Size(1022, 768);
            this.panfull.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.panRight);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(200, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(822, 768);
            this.panel6.TabIndex = 4;
            // 
            // panRight
            // 
            this.panRight.BackColor = System.Drawing.Color.White;
            this.panRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panRight.Location = new System.Drawing.Point(0, 48);
            this.panRight.Name = "panRight";
            this.panRight.Size = new System.Drawing.Size(822, 720);
            this.panRight.TabIndex = 1;
            this.panRight.Click += new System.EventHandler(this.btnUnLoadTimeOutAlarm_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(247)))), ((int)(((byte)(249)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.labelX6);
            this.panel7.Controls.Add(this.lblNav);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(822, 48);
            this.panel7.TabIndex = 0;
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelX6.Location = new System.Drawing.Point(12, 12);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(75, 23);
            this.labelX6.TabIndex = 11;
            this.labelX6.Text = "当前页面 >";
            // 
            // lblNav
            // 
            // 
            // 
            // 
            this.lblNav.BackgroundStyle.Class = "";
            this.lblNav.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.lblNav.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblNav.Location = new System.Drawing.Point(85, 12);
            this.lblNav.Name = "lblNav";
            this.lblNav.Size = new System.Drawing.Size(75, 23);
            this.lblNav.TabIndex = 10;
            this.lblNav.Text = "首页";
            // 
            // panelleft
            // 
            this.panelleft.BackColor = System.Drawing.Color.Transparent;
            this.panelleft.Controls.Add(this.panelLeftBar);
            this.panelleft.Controls.Add(this.panel8);
            this.panelleft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelleft.Location = new System.Drawing.Point(0, 0);
            this.panelleft.Name = "panelleft";
            this.panelleft.Size = new System.Drawing.Size(200, 768);
            this.panelleft.TabIndex = 3;
            // 
            // panelLeftBar
            // 
            this.panelLeftBar.AutoScroll = true;
            this.panelLeftBar.Controls.Add(this.panelConfig);
            this.panelLeftBar.Controls.Add(this.panelAlarm);
            this.panelLeftBar.Controls.Add(this.panelAnaly);
            this.panelLeftBar.Controls.Add(this.panelBaseinfo);
            this.panelLeftBar.Controls.Add(this.panelFlow);
            this.panelLeftBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLeftBar.Location = new System.Drawing.Point(0, 48);
            this.panelLeftBar.Name = "panelLeftBar";
            this.panelLeftBar.Size = new System.Drawing.Size(200, 720);
            this.panelLeftBar.TabIndex = 5;
            // 
            // panelConfig
            // 
            this.panelConfig.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelConfig.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelConfig.Controls.Add(this.itemPanel5);
            this.panelConfig.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelConfig.ExpandButtonVisible = false;
            this.panelConfig.ExpandOnTitleClick = true;
            this.panelConfig.Location = new System.Drawing.Point(0, 1174);
            this.panelConfig.Name = "panelConfig";
            this.panelConfig.Size = new System.Drawing.Size(183, 174);
            this.panelConfig.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelConfig.Style.BackColor1.Color = System.Drawing.Color.White;
            this.panelConfig.Style.BackColor2.Color = System.Drawing.Color.White;
            this.panelConfig.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelConfig.Style.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.panelConfig.Style.BorderWidth = 0;
            this.panelConfig.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelConfig.Style.GradientAngle = 90;
            this.panelConfig.TabIndex = 7;
            this.panelConfig.TitleHeight = 30;
            this.panelConfig.TitleStyle.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.panelConfig.TitleStyle.BackgroundImage = global::VehicleTransportClient.Properties.Resources.系统设置;
            this.panelConfig.TitleStyle.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.CenterLeft;
            this.panelConfig.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelConfig.TitleStyle.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(213)))), ((int)(((byte)(223)))));
            this.panelConfig.TitleStyle.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.panelConfig.TitleStyle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelConfig.TitleStyle.ForeColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(89)))), ((int)(((byte)(136)))));
            this.panelConfig.TitleStyle.GradientAngle = 90;
            this.panelConfig.TitleStyle.MarginLeft = 30;
            this.panelConfig.TitleStyle.TextTrimming = System.Drawing.StringTrimming.EllipsisWord;
            this.panelConfig.TitleText = "系统管理";
            this.panelConfig.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelConfig_ExpandedChanged);
            // 
            // itemPanel5
            // 
            // 
            // 
            // 
            this.itemPanel5.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            this.itemPanel5.BackgroundStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.itemPanel5.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel5.ContainerControlProcessDialogKey = true;
            this.itemPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel5.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnUserManage,
            this.btnRuleManage,
            this.btnPasswordEdit,
            this.btnAlarmSet,
            this.btnSystemLog});
            this.itemPanel5.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel5.Location = new System.Drawing.Point(0, 30);
            this.itemPanel5.Name = "itemPanel5";
            this.itemPanel5.Size = new System.Drawing.Size(183, 144);
            this.itemPanel5.TabIndex = 1;
            this.itemPanel5.Text = "itemPanel5";
            // 
            // btnUserManage
            // 
            this.btnUserManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnUserManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnUserManage.Image = ((System.Drawing.Image)(resources.GetObject("btnUserManage.Image")));
            this.btnUserManage.ImagePaddingVertical = 10;
            this.btnUserManage.Name = "btnUserManage";
            this.btnUserManage.Text = "用户管理";
            this.btnUserManage.Click += new System.EventHandler(this.btnUserManage_Click);
            // 
            // btnRuleManage
            // 
            this.btnRuleManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnRuleManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnRuleManage.Image = ((System.Drawing.Image)(resources.GetObject("btnRuleManage.Image")));
            this.btnRuleManage.ImagePaddingVertical = 10;
            this.btnRuleManage.Name = "btnRuleManage";
            this.btnRuleManage.Text = "角色管理";
            this.btnRuleManage.Click += new System.EventHandler(this.btnRuleManage_Click);
            // 
            // btnPasswordEdit
            // 
            this.btnPasswordEdit.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnPasswordEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnPasswordEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnPasswordEdit.Image")));
            this.btnPasswordEdit.ImagePaddingVertical = 10;
            this.btnPasswordEdit.Name = "btnPasswordEdit";
            this.btnPasswordEdit.Text = "密码修改";
            this.btnPasswordEdit.Click += new System.EventHandler(this.btnPasswordEdit_Click);
            // 
            // btnAlarmSet
            // 
            this.btnAlarmSet.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnAlarmSet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnAlarmSet.Image = ((System.Drawing.Image)(resources.GetObject("btnAlarmSet.Image")));
            this.btnAlarmSet.ImagePaddingVertical = 10;
            this.btnAlarmSet.Name = "btnAlarmSet";
            this.btnAlarmSet.Text = "系统设置";
            this.btnAlarmSet.Click += new System.EventHandler(this.btnAlarmSet_Click);
            // 
            // btnSystemLog
            // 
            this.btnSystemLog.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnSystemLog.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnSystemLog.Image = ((System.Drawing.Image)(resources.GetObject("btnSystemLog.Image")));
            this.btnSystemLog.ImagePaddingVertical = 10;
            this.btnSystemLog.Name = "btnSystemLog";
            this.btnSystemLog.Text = "系统日志";
            this.btnSystemLog.Click += new System.EventHandler(this.btnSystemLog_Click);
            // 
            // panelAlarm
            // 
            this.panelAlarm.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelAlarm.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelAlarm.Controls.Add(this.itemPanel4);
            this.panelAlarm.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAlarm.ExpandButtonVisible = false;
            this.panelAlarm.ExpandOnTitleClick = true;
            this.panelAlarm.Location = new System.Drawing.Point(0, 838);
            this.panelAlarm.Name = "panelAlarm";
            this.panelAlarm.Size = new System.Drawing.Size(183, 336);
            this.panelAlarm.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelAlarm.Style.BackColor1.Color = System.Drawing.Color.White;
            this.panelAlarm.Style.BackColor2.Color = System.Drawing.Color.White;
            this.panelAlarm.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelAlarm.Style.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.panelAlarm.Style.BorderWidth = 0;
            this.panelAlarm.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelAlarm.Style.GradientAngle = 90;
            this.panelAlarm.TabIndex = 6;
            this.panelAlarm.TitleHeight = 30;
            this.panelAlarm.TitleStyle.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.panelAlarm.TitleStyle.BackgroundImage = global::VehicleTransportClient.Properties.Resources.告警查询;
            this.panelAlarm.TitleStyle.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.CenterLeft;
            this.panelAlarm.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelAlarm.TitleStyle.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(213)))), ((int)(((byte)(223)))));
            this.panelAlarm.TitleStyle.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.panelAlarm.TitleStyle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelAlarm.TitleStyle.ForeColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(89)))), ((int)(((byte)(136)))));
            this.panelAlarm.TitleStyle.GradientAngle = 90;
            this.panelAlarm.TitleStyle.MarginLeft = 30;
            this.panelAlarm.TitleStyle.TextTrimming = System.Drawing.StringTrimming.EllipsisWord;
            this.panelAlarm.TitleText = "告警查询";
            this.panelAlarm.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelAlarm_ExpandedChanged);
            // 
            // itemPanel4
            // 
            // 
            // 
            // 
            this.itemPanel4.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            this.itemPanel4.BackgroundStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.itemPanel4.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel4.ContainerControlProcessDialogKey = true;
            this.itemPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnMaintainTimeOutAlarm,
            this.btnScrapTimeOutAlarm,
            this.btnGiveTimeOutAlarm,
            this.btnLoadTimeOutAlarm,
            this.btnTransportTimeOutAlarm,
            this.btnUnLoadTimeOutAlarm,
            this.btnBackTimeOutAlarm,
            this.btnNoUseAlarm,
            this.btnRunDerictionAlarm,
            this.btnNoChanageStateAlarm,
            this.btnSendMessage});
            this.itemPanel4.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel4.Location = new System.Drawing.Point(0, 30);
            this.itemPanel4.Name = "itemPanel4";
            this.itemPanel4.Size = new System.Drawing.Size(183, 306);
            this.itemPanel4.TabIndex = 1;
            this.itemPanel4.Text = "itemPanel4";
            // 
            // btnMaintainTimeOutAlarm
            // 
            this.btnMaintainTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnMaintainTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnMaintainTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnMaintainTimeOutAlarm.Image")));
            this.btnMaintainTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnMaintainTimeOutAlarm.Name = "btnMaintainTimeOutAlarm";
            this.btnMaintainTimeOutAlarm.Text = "检修超期告警";
            this.btnMaintainTimeOutAlarm.Click += new System.EventHandler(this.btnMaintainTimeOutAlarm_Click);
            // 
            // btnScrapTimeOutAlarm
            // 
            this.btnScrapTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnScrapTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnScrapTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnScrapTimeOutAlarm.Image")));
            this.btnScrapTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnScrapTimeOutAlarm.Name = "btnScrapTimeOutAlarm";
            this.btnScrapTimeOutAlarm.Text = "报废超期告警";
            this.btnScrapTimeOutAlarm.Click += new System.EventHandler(this.btnScrapTimeOutAlarm_Click);
            // 
            // btnGiveTimeOutAlarm
            // 
            this.btnGiveTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGiveTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnGiveTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnGiveTimeOutAlarm.Image")));
            this.btnGiveTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnGiveTimeOutAlarm.Name = "btnGiveTimeOutAlarm";
            this.btnGiveTimeOutAlarm.Text = "供车不及时告警";
            this.btnGiveTimeOutAlarm.Click += new System.EventHandler(this.btnGiveTimeOutAlarm_Click);
            // 
            // btnLoadTimeOutAlarm
            // 
            this.btnLoadTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnLoadTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnLoadTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadTimeOutAlarm.Image")));
            this.btnLoadTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnLoadTimeOutAlarm.Name = "btnLoadTimeOutAlarm";
            this.btnLoadTimeOutAlarm.Text = "装车不及时告警";
            this.btnLoadTimeOutAlarm.Click += new System.EventHandler(this.btnLoadTimeOutAlarm_Click);
            // 
            // btnTransportTimeOutAlarm
            // 
            this.btnTransportTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnTransportTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnTransportTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnTransportTimeOutAlarm.Image")));
            this.btnTransportTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnTransportTimeOutAlarm.Name = "btnTransportTimeOutAlarm";
            this.btnTransportTimeOutAlarm.Text = "未按时运送告警";
            this.btnTransportTimeOutAlarm.Click += new System.EventHandler(this.btnTransportTimeOutAlarm_Click);
            // 
            // btnUnLoadTimeOutAlarm
            // 
            this.btnUnLoadTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnUnLoadTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnUnLoadTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnUnLoadTimeOutAlarm.Image")));
            this.btnUnLoadTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnUnLoadTimeOutAlarm.Name = "btnUnLoadTimeOutAlarm";
            this.btnUnLoadTimeOutAlarm.Text = "卸车不及时告警";
            this.btnUnLoadTimeOutAlarm.Click += new System.EventHandler(this.btnUnLoadTimeOutAlarm_Click);
            // 
            // btnBackTimeOutAlarm
            // 
            this.btnBackTimeOutAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnBackTimeOutAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnBackTimeOutAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnBackTimeOutAlarm.Image")));
            this.btnBackTimeOutAlarm.ImagePaddingVertical = 10;
            this.btnBackTimeOutAlarm.Name = "btnBackTimeOutAlarm";
            this.btnBackTimeOutAlarm.Text = "还车不及时告警";
            this.btnBackTimeOutAlarm.Click += new System.EventHandler(this.btnBackTimeOutAlarm_Click);
            // 
            // btnNoUseAlarm
            // 
            this.btnNoUseAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNoUseAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnNoUseAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnNoUseAlarm.Image")));
            this.btnNoUseAlarm.ImagePaddingVertical = 10;
            this.btnNoUseAlarm.Name = "btnNoUseAlarm";
            this.btnNoUseAlarm.Text = "闲置告警";
            this.btnNoUseAlarm.Click += new System.EventHandler(this.btnNoUseAlarm_Click);
            // 
            // btnRunDerictionAlarm
            // 
            this.btnRunDerictionAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnRunDerictionAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnRunDerictionAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnRunDerictionAlarm.Image")));
            this.btnRunDerictionAlarm.ImagePaddingVertical = 10;
            this.btnRunDerictionAlarm.Name = "btnRunDerictionAlarm";
            this.btnRunDerictionAlarm.Text = "运行方向不正确告警";
            this.btnRunDerictionAlarm.Click += new System.EventHandler(this.btnRunDerictionAlarm_Click);
            // 
            // btnNoChanageStateAlarm
            // 
            this.btnNoChanageStateAlarm.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNoChanageStateAlarm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnNoChanageStateAlarm.Image = ((System.Drawing.Image)(resources.GetObject("btnNoChanageStateAlarm.Image")));
            this.btnNoChanageStateAlarm.ImagePaddingVertical = 10;
            this.btnNoChanageStateAlarm.Name = "btnNoChanageStateAlarm";
            this.btnNoChanageStateAlarm.Text = "未置换状态告警";
            this.btnNoChanageStateAlarm.Click += new System.EventHandler(this.btnNoChanageStateAlarm_Click);
            // 
            // btnSendMessage
            // 
            this.btnSendMessage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnSendMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnSendMessage.Image = ((System.Drawing.Image)(resources.GetObject("btnSendMessage.Image")));
            this.btnSendMessage.ImagePaddingVertical = 10;
            this.btnSendMessage.Name = "btnSendMessage";
            this.btnSendMessage.Text = "消息查询";
            this.btnSendMessage.Click += new System.EventHandler(this.btnSendMessage_Click);
            // 
            // panelAnaly
            // 
            this.panelAnaly.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelAnaly.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelAnaly.Controls.Add(this.itemPanel1);
            this.panelAnaly.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAnaly.ExpandButtonVisible = false;
            this.panelAnaly.ExpandOnTitleClick = true;
            this.panelAnaly.Location = new System.Drawing.Point(0, 607);
            this.panelAnaly.Name = "panelAnaly";
            this.panelAnaly.Size = new System.Drawing.Size(183, 231);
            this.panelAnaly.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelAnaly.Style.BackColor1.Color = System.Drawing.Color.White;
            this.panelAnaly.Style.BackColor2.Color = System.Drawing.Color.White;
            this.panelAnaly.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelAnaly.Style.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.panelAnaly.Style.BorderWidth = 0;
            this.panelAnaly.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelAnaly.Style.GradientAngle = 90;
            this.panelAnaly.TabIndex = 5;
            this.panelAnaly.TitleHeight = 30;
            this.panelAnaly.TitleStyle.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.panelAnaly.TitleStyle.BackgroundImage = global::VehicleTransportClient.Properties.Resources.统计分析;
            this.panelAnaly.TitleStyle.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.CenterLeft;
            this.panelAnaly.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelAnaly.TitleStyle.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(213)))), ((int)(((byte)(223)))));
            this.panelAnaly.TitleStyle.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.panelAnaly.TitleStyle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelAnaly.TitleStyle.ForeColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(89)))), ((int)(((byte)(136)))));
            this.panelAnaly.TitleStyle.GradientAngle = 90;
            this.panelAnaly.TitleStyle.MarginLeft = 30;
            this.panelAnaly.TitleStyle.TextTrimming = System.Drawing.StringTrimming.EllipsisWord;
            this.panelAnaly.TitleText = "统计分析";
            this.panelAnaly.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelAnaly_ExpandedChanged);
            // 
            // itemPanel1
            // 
            // 
            // 
            // 
            this.itemPanel1.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            this.itemPanel1.BackgroundStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.itemPanel1.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel1.ContainerControlProcessDialogKey = true;
            this.itemPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnVehicleDept,
            this.btnDeptMaterielTypeReport,
            this.btnVehicleMonth,
            this.btnMaterielReport,
            this.btnNoUseMonthReport,
            this.buttonItem7,
            this.buttonItem8});
            this.itemPanel1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel1.Location = new System.Drawing.Point(0, 30);
            this.itemPanel1.Name = "itemPanel1";
            this.itemPanel1.Size = new System.Drawing.Size(183, 201);
            this.itemPanel1.TabIndex = 1;
            this.itemPanel1.Text = "itemPanel1";
            // 
            // btnVehicleDept
            // 
            this.btnVehicleDept.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnVehicleDept.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnVehicleDept.Image = ((System.Drawing.Image)(resources.GetObject("btnVehicleDept.Image")));
            this.btnVehicleDept.ImagePaddingVertical = 10;
            this.btnVehicleDept.Name = "btnVehicleDept";
            this.btnVehicleDept.Text = "部门车辆使用表";
            this.btnVehicleDept.Click += new System.EventHandler(this.btnVehicleDept_Click);
            // 
            // btnVehicleMonth
            // 
            this.btnVehicleMonth.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnVehicleMonth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnVehicleMonth.Image = ((System.Drawing.Image)(resources.GetObject("btnVehicleMonth.Image")));
            this.btnVehicleMonth.ImagePaddingVertical = 10;
            this.btnVehicleMonth.Name = "btnVehicleMonth";
            this.btnVehicleMonth.Text = "车辆使用月报表";
            this.btnVehicleMonth.Click += new System.EventHandler(this.btnVehicleMonth_Click);
            // 
            // btnMaterielReport
            // 
            this.btnMaterielReport.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnMaterielReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnMaterielReport.Image = ((System.Drawing.Image)(resources.GetObject("btnMaterielReport.Image")));
            this.btnMaterielReport.ImagePaddingVertical = 10;
            this.btnMaterielReport.Name = "btnMaterielReport";
            this.btnMaterielReport.Text = "物料使用月报表";
            this.btnMaterielReport.Click += new System.EventHandler(this.btnMaterielReport_Click);
            // 
            // btnNoUseMonthReport
            // 
            this.btnNoUseMonthReport.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnNoUseMonthReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnNoUseMonthReport.Image = ((System.Drawing.Image)(resources.GetObject("btnNoUseMonthReport.Image")));
            this.btnNoUseMonthReport.ImagePaddingVertical = 10;
            this.btnNoUseMonthReport.Name = "btnNoUseMonthReport";
            this.btnNoUseMonthReport.Text = "车辆闲置月报表";
            this.btnNoUseMonthReport.Click += new System.EventHandler(this.btnNoUseMonthReport_Click);
            // 
            // buttonItem7
            // 
            this.buttonItem7.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.buttonItem7.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem7.Image")));
            this.buttonItem7.ImagePaddingVertical = 10;
            this.buttonItem7.Name = "buttonItem7";
            this.buttonItem7.Text = "车辆调度";
            // 
            // buttonItem8
            // 
            this.buttonItem8.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.buttonItem8.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem8.Image")));
            this.buttonItem8.ImagePaddingVertical = 10;
            this.buttonItem8.Name = "buttonItem8";
            this.buttonItem8.Text = "车辆临时调度计划";
            // 
            // panelBaseinfo
            // 
            this.panelBaseinfo.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelBaseinfo.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelBaseinfo.Controls.Add(this.itemPanel2);
            this.panelBaseinfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBaseinfo.ExpandButtonVisible = false;
            this.panelBaseinfo.ExpandOnTitleClick = true;
            this.panelBaseinfo.Location = new System.Drawing.Point(0, 232);
            this.panelBaseinfo.Name = "panelBaseinfo";
            this.panelBaseinfo.Size = new System.Drawing.Size(183, 375);
            this.panelBaseinfo.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelBaseinfo.Style.BackColor1.Color = System.Drawing.Color.White;
            this.panelBaseinfo.Style.BackColor2.Color = System.Drawing.Color.White;
            this.panelBaseinfo.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelBaseinfo.Style.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.panelBaseinfo.Style.BorderWidth = 0;
            this.panelBaseinfo.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelBaseinfo.Style.GradientAngle = 90;
            this.panelBaseinfo.TabIndex = 4;
            this.panelBaseinfo.TitleHeight = 30;
            this.panelBaseinfo.TitleStyle.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.panelBaseinfo.TitleStyle.BackgroundImage = global::VehicleTransportClient.Properties.Resources.基础信息管理;
            this.panelBaseinfo.TitleStyle.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.CenterLeft;
            this.panelBaseinfo.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelBaseinfo.TitleStyle.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(231)))), ((int)(((byte)(223)))));
            this.panelBaseinfo.TitleStyle.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.panelBaseinfo.TitleStyle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelBaseinfo.TitleStyle.ForeColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(89)))), ((int)(((byte)(136)))));
            this.panelBaseinfo.TitleStyle.GradientAngle = 90;
            this.panelBaseinfo.TitleStyle.MarginLeft = 30;
            this.panelBaseinfo.TitleStyle.TextTrimming = System.Drawing.StringTrimming.EllipsisWord;
            this.panelBaseinfo.TitleText = "基础信息管理";
            this.panelBaseinfo.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelBaseinfo_ExpandedChanged);
            // 
            // itemPanel2
            // 
            // 
            // 
            // 
            this.itemPanel2.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            this.itemPanel2.BackgroundStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.itemPanel2.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel2.ContainerControlProcessDialogKey = true;
            this.itemPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnPersonManage,
            this.btnDeptManage,
            this.btnAreaManage,
            this.btnStationManage,
            this.btnWifiStation,
            this.btnCarTypeManage,
            this.btnCarManage,
            this.btnVehicleMaintain,
            this.btnCarScraped,
            this.btnPDAManage,
            this.btnCardManage,
            this.btnMaterielType});
            this.itemPanel2.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel2.Location = new System.Drawing.Point(0, 30);
            this.itemPanel2.Name = "itemPanel2";
            this.itemPanel2.Size = new System.Drawing.Size(183, 345);
            this.itemPanel2.TabIndex = 2;
            this.itemPanel2.Text = "itemPanel2";
            // 
            // btnPersonManage
            // 
            this.btnPersonManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnPersonManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnPersonManage.Image = ((System.Drawing.Image)(resources.GetObject("btnPersonManage.Image")));
            this.btnPersonManage.ImagePaddingVertical = 10;
            this.btnPersonManage.Name = "btnPersonManage";
            this.btnPersonManage.Text = "人员管理";
            this.btnPersonManage.Click += new System.EventHandler(this.btnPersonManage_Click);
            // 
            // btnDeptManage
            // 
            this.btnDeptManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDeptManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnDeptManage.Image = ((System.Drawing.Image)(resources.GetObject("btnDeptManage.Image")));
            this.btnDeptManage.ImagePaddingVertical = 10;
            this.btnDeptManage.Name = "btnDeptManage";
            this.btnDeptManage.Text = "部门管理";
            this.btnDeptManage.Click += new System.EventHandler(this.btnDeptManage_Click);
            // 
            // btnAreaManage
            // 
            this.btnAreaManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnAreaManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnAreaManage.Image = ((System.Drawing.Image)(resources.GetObject("btnAreaManage.Image")));
            this.btnAreaManage.ImagePaddingVertical = 10;
            this.btnAreaManage.Name = "btnAreaManage";
            this.btnAreaManage.Text = "区域管理";
            this.btnAreaManage.Click += new System.EventHandler(this.btnAreaManage_Click);
            // 
            // btnStationManage
            // 
            this.btnStationManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnStationManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnStationManage.Image = ((System.Drawing.Image)(resources.GetObject("btnStationManage.Image")));
            this.btnStationManage.ImagePaddingVertical = 10;
            this.btnStationManage.Name = "btnStationManage";
            this.btnStationManage.Text = "定位基站管理";
            this.btnStationManage.Click += new System.EventHandler(this.btnStationManage_Click);
            // 
            // btnWifiStation
            // 
            this.btnWifiStation.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnWifiStation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnWifiStation.Image = ((System.Drawing.Image)(resources.GetObject("btnWifiStation.Image")));
            this.btnWifiStation.ImagePaddingVertical = 10;
            this.btnWifiStation.Name = "btnWifiStation";
            this.btnWifiStation.Text = "wifi基站管理";
            this.btnWifiStation.Click += new System.EventHandler(this.btnWifiStation_Click);
            // 
            // btnCarTypeManage
            // 
            this.btnCarTypeManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCarTypeManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnCarTypeManage.Image = ((System.Drawing.Image)(resources.GetObject("btnCarTypeManage.Image")));
            this.btnCarTypeManage.ImagePaddingVertical = 10;
            this.btnCarTypeManage.Name = "btnCarTypeManage";
            this.btnCarTypeManage.Text = "车辆类型管理";
            this.btnCarTypeManage.Click += new System.EventHandler(this.btnCarTypeManage_Click);
            // 
            // btnCarManage
            // 
            this.btnCarManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCarManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnCarManage.Image = ((System.Drawing.Image)(resources.GetObject("btnCarManage.Image")));
            this.btnCarManage.ImagePaddingVertical = 10;
            this.btnCarManage.Name = "btnCarManage";
            this.btnCarManage.Text = "车辆管理";
            this.btnCarManage.Click += new System.EventHandler(this.btnCarManage_Click);
            // 
            // btnVehicleMaintain
            // 
            this.btnVehicleMaintain.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnVehicleMaintain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnVehicleMaintain.Image = ((System.Drawing.Image)(resources.GetObject("btnVehicleMaintain.Image")));
            this.btnVehicleMaintain.ImagePaddingVertical = 10;
            this.btnVehicleMaintain.Name = "btnVehicleMaintain";
            this.btnVehicleMaintain.Text = "车辆维护管理";
            this.btnVehicleMaintain.Click += new System.EventHandler(this.btnVehicleMaintain_Click);
            // 
            // btnCarScraped
            // 
            this.btnCarScraped.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCarScraped.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnCarScraped.Image = ((System.Drawing.Image)(resources.GetObject("btnCarScraped.Image")));
            this.btnCarScraped.ImagePaddingVertical = 10;
            this.btnCarScraped.Name = "btnCarScraped";
            this.btnCarScraped.Text = "车辆报废管理";
            this.btnCarScraped.Click += new System.EventHandler(this.btnCarScraped_Click);
            // 
            // btnPDAManage
            // 
            this.btnPDAManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnPDAManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnPDAManage.Image = ((System.Drawing.Image)(resources.GetObject("btnPDAManage.Image")));
            this.btnPDAManage.ImagePaddingVertical = 10;
            this.btnPDAManage.Name = "btnPDAManage";
            this.btnPDAManage.Text = "PDA管理";
            this.btnPDAManage.Click += new System.EventHandler(this.btnPDAManage_Click);
            // 
            // btnCardManage
            // 
            this.btnCardManage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCardManage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnCardManage.Image = ((System.Drawing.Image)(resources.GetObject("btnCardManage.Image")));
            this.btnCardManage.ImagePaddingVertical = 10;
            this.btnCardManage.Name = "btnCardManage";
            this.btnCardManage.Text = "车辆发卡";
            this.btnCardManage.Click += new System.EventHandler(this.btnCardManage_Click);
            // 
            // btnMaterielType
            // 
            this.btnMaterielType.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnMaterielType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnMaterielType.Image = ((System.Drawing.Image)(resources.GetObject("btnMaterielType.Image")));
            this.btnMaterielType.ImagePaddingVertical = 10;
            this.btnMaterielType.Name = "btnMaterielType";
            this.btnMaterielType.Text = "物料管理";
            this.btnMaterielType.Click += new System.EventHandler(this.btnMaterielType_Click);
            // 
            // panelFlow
            // 
            this.panelFlow.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelFlow.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelFlow.Controls.Add(this.itemPanel3);
            this.panelFlow.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFlow.ExpandButtonVisible = false;
            this.panelFlow.ExpandOnTitleClick = true;
            this.panelFlow.Location = new System.Drawing.Point(0, 0);
            this.panelFlow.Name = "panelFlow";
            this.panelFlow.Size = new System.Drawing.Size(183, 232);
            this.panelFlow.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelFlow.Style.BackColor1.Color = System.Drawing.Color.White;
            this.panelFlow.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.panelFlow.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelFlow.Style.BorderDashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.panelFlow.Style.BorderWidth = 0;
            this.panelFlow.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelFlow.Style.GradientAngle = 90;
            this.panelFlow.TabIndex = 3;
            this.panelFlow.TitleHeight = 30;
            this.panelFlow.TitleStyle.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.panelFlow.TitleStyle.BackgroundImage = global::VehicleTransportClient.Properties.Resources.物料运输管理;
            this.panelFlow.TitleStyle.BackgroundImagePosition = DevComponents.DotNetBar.eBackgroundImagePosition.CenterLeft;
            this.panelFlow.TitleStyle.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelFlow.TitleStyle.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(213)))), ((int)(((byte)(223)))));
            this.panelFlow.TitleStyle.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.panelFlow.TitleStyle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panelFlow.TitleStyle.ForeColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(89)))), ((int)(((byte)(136)))));
            this.panelFlow.TitleStyle.GradientAngle = 90;
            this.panelFlow.TitleStyle.MarginLeft = 30;
            this.panelFlow.TitleStyle.TextTrimming = System.Drawing.StringTrimming.EllipsisWord;
            this.panelFlow.TitleText = "物料运输管理";
            this.panelFlow.ExpandedChanged += new DevComponents.DotNetBar.ExpandChangeEventHandler(this.panelFlow_ExpandedChanged);
            // 
            // itemPanel3
            // 
            this.itemPanel3.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.itemPanel3.BackgroundStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(249)))), ((int)(((byte)(254)))));
            this.itemPanel3.BackgroundStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(252)))));
            this.itemPanel3.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel3.ContainerControlProcessDialogKey = true;
            this.itemPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnmyapply,
            this.btnCheck,
            this.btnSupply,
            this.btnloadcar,
            this.btnTransfer,
            this.btnunload,
            this.btnbackcar});
            this.itemPanel3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel3.Location = new System.Drawing.Point(0, 30);
            this.itemPanel3.Name = "itemPanel3";
            this.itemPanel3.Size = new System.Drawing.Size(183, 202);
            this.itemPanel3.TabIndex = 2;
            this.itemPanel3.Text = "itemPanel3";
            // 
            // btnmyapply
            // 
            this.btnmyapply.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnmyapply.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnmyapply.HotForeColor = System.Drawing.Color.White;
            this.btnmyapply.Image = global::VehicleTransportClient.Properties.Resources.其他图标;
            this.btnmyapply.ImagePaddingVertical = 10;
            this.btnmyapply.Name = "btnmyapply";
            this.btnmyapply.Text = "我的申请";
            this.btnmyapply.Click += new System.EventHandler(this.btnmyapply_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnCheck.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnCheck.HotForeColor = System.Drawing.Color.White;
            this.btnCheck.Image = ((System.Drawing.Image)(resources.GetObject("btnCheck.Image")));
            this.btnCheck.ImagePaddingVertical = 10;
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Text = "审核";
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnSupply
            // 
            this.btnSupply.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnSupply.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnSupply.HotForeColor = System.Drawing.Color.White;
            this.btnSupply.Image = ((System.Drawing.Image)(resources.GetObject("btnSupply.Image")));
            this.btnSupply.ImagePaddingVertical = 10;
            this.btnSupply.Name = "btnSupply";
            this.btnSupply.Text = "供车";
            this.btnSupply.Click += new System.EventHandler(this.btnSupply_Click);
            // 
            // btnloadcar
            // 
            this.btnloadcar.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnloadcar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnloadcar.HotForeColor = System.Drawing.Color.White;
            this.btnloadcar.Image = ((System.Drawing.Image)(resources.GetObject("btnloadcar.Image")));
            this.btnloadcar.ImagePaddingVertical = 10;
            this.btnloadcar.Name = "btnloadcar";
            this.btnloadcar.Text = "装车";
            this.btnloadcar.Click += new System.EventHandler(this.btnloadcar_Click);
            // 
            // btnTransfer
            // 
            this.btnTransfer.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnTransfer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnTransfer.HotForeColor = System.Drawing.Color.White;
            this.btnTransfer.Image = ((System.Drawing.Image)(resources.GetObject("btnTransfer.Image")));
            this.btnTransfer.ImagePaddingVertical = 10;
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Text = "交接车";
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // btnunload
            // 
            this.btnunload.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnunload.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnunload.HotForeColor = System.Drawing.Color.White;
            this.btnunload.Image = ((System.Drawing.Image)(resources.GetObject("btnunload.Image")));
            this.btnunload.ImagePaddingVertical = 10;
            this.btnunload.Name = "btnunload";
            this.btnunload.Text = "卸车";
            this.btnunload.Click += new System.EventHandler(this.btnunload_Click);
            // 
            // btnbackcar
            // 
            this.btnbackcar.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnbackcar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnbackcar.HotForeColor = System.Drawing.Color.White;
            this.btnbackcar.Image = ((System.Drawing.Image)(resources.GetObject("btnbackcar.Image")));
            this.btnbackcar.ImagePaddingVertical = 10;
            this.btnbackcar.Name = "btnbackcar";
            this.btnbackcar.Text = "还车";
            this.btnbackcar.Click += new System.EventHandler(this.btnbackcar_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(153)))), ((int)(((byte)(204)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.labuser);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(200, 48);
            this.panel8.TabIndex = 1;
            // 
            // labuser
            // 
            this.labuser.AutoSize = true;
            this.labuser.Font = new System.Drawing.Font("宋体", 9.5F);
            this.labuser.ForeColor = System.Drawing.Color.White;
            this.labuser.Location = new System.Drawing.Point(78, 18);
            this.labuser.Name = "labuser";
            this.labuser.Size = new System.Drawing.Size(88, 13);
            this.labuser.TabIndex = 1;
            this.labuser.Text = "用户名:admin";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::VehicleTransportClient.Properties.Resources.yonghu;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(31, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 25);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnDeptMaterielTypeReport
            // 
            this.btnDeptMaterielTypeReport.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDeptMaterielTypeReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(124)))), ((int)(((byte)(175)))));
            this.btnDeptMaterielTypeReport.Image = ((System.Drawing.Image)(resources.GetObject("btnDeptMaterielTypeReport.Image")));
            this.btnDeptMaterielTypeReport.ImagePaddingVertical = 10;
            this.btnDeptMaterielTypeReport.Name = "btnDeptMaterielTypeReport";
            this.btnDeptMaterielTypeReport.Text = "部门物料使用表";
            this.btnDeptMaterielTypeReport.Click += new System.EventHandler(this.btnDeptMaterielTypeReport_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 912);
            this.FormTitle = "矿用机车运输管理系统(0.0.3.0)";
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "矿用机车运输管理系统(0.0.3.1)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.panelWorkArea.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panfull.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panelleft.ResumeLayout(false);
            this.panelLeftBar.ResumeLayout(false);
            this.panelConfig.ResumeLayout(false);
            this.panelAlarm.ResumeLayout(false);
            this.panelAnaly.ResumeLayout(false);
            this.panelBaseinfo.ResumeLayout(false);
            this.panelFlow.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private DevComponents.DotNetBar.ButtonX btnquery;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.ButtonX btnMap;
        private DevComponents.DotNetBar.ButtonX btnCheckMgr;
        private DevComponents.DotNetBar.ButtonX btnApply;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX lbdbstate;
        private DevComponents.DotNetBar.LabelX lbstate;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX8;

      
        private DevComponents.DotNetBar.ButtonItem buttonItem1;

        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
        private DevComponents.DotNetBar.ButtonItem buttonItem9;
        private DevComponents.DotNetBar.ButtonItem buttonItem10;

     

        private System.Windows.Forms.Panel panfull;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panRight;
        private System.Windows.Forms.Panel panel7;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX lblNav;
        private System.Windows.Forms.Panel panelleft;
        private System.Windows.Forms.Panel panelLeftBar;
        private DevComponents.DotNetBar.ExpandablePanel panelConfig;
        private DevComponents.DotNetBar.ItemPanel itemPanel5;
        private DevComponents.DotNetBar.ButtonItem btnUserManage;
        private DevComponents.DotNetBar.ButtonItem btnRuleManage;
        private DevComponents.DotNetBar.ButtonItem btnPasswordEdit;
        private DevComponents.DotNetBar.ButtonItem btnAlarmSet;
        private DevComponents.DotNetBar.ButtonItem btnSystemLog;
        private DevComponents.DotNetBar.ExpandablePanel panelAlarm;
        private DevComponents.DotNetBar.ItemPanel itemPanel4;
        private DevComponents.DotNetBar.ButtonItem btnMaintainTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnScrapTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnGiveTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnLoadTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnTransportTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnUnLoadTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnBackTimeOutAlarm;
        private DevComponents.DotNetBar.ButtonItem btnNoUseAlarm;
        private DevComponents.DotNetBar.ButtonItem btnRunDerictionAlarm;
        private DevComponents.DotNetBar.ButtonItem btnNoChanageStateAlarm;
        private DevComponents.DotNetBar.ButtonItem btnSendMessage;
        private DevComponents.DotNetBar.ExpandablePanel panelAnaly;
        private DevComponents.DotNetBar.ItemPanel itemPanel1;
        private DevComponents.DotNetBar.ButtonItem btnVehicleMonth;
        private DevComponents.DotNetBar.ButtonItem btnMaterielReport;
        private DevComponents.DotNetBar.ButtonItem btnNoUseMonthReport;
        private DevComponents.DotNetBar.ButtonItem buttonItem7;
        private DevComponents.DotNetBar.ButtonItem buttonItem8;
        private DevComponents.DotNetBar.ExpandablePanel panelBaseinfo;
        private DevComponents.DotNetBar.ItemPanel itemPanel2;
        private DevComponents.DotNetBar.ButtonItem btnPersonManage;
        private DevComponents.DotNetBar.ButtonItem btnDeptManage;
        private DevComponents.DotNetBar.ButtonItem btnAreaManage;
        private DevComponents.DotNetBar.ButtonItem btnStationManage;
        private DevComponents.DotNetBar.ButtonItem btnWifiStation;
        private DevComponents.DotNetBar.ButtonItem btnCarTypeManage;
        private DevComponents.DotNetBar.ButtonItem btnCarManage;
        private DevComponents.DotNetBar.ButtonItem btnVehicleMaintain;
        private DevComponents.DotNetBar.ButtonItem btnCarScraped;
        private DevComponents.DotNetBar.ButtonItem btnPDAManage;
        private DevComponents.DotNetBar.ButtonItem btnCardManage;
        private DevComponents.DotNetBar.ButtonItem btnMaterielType;
        private DevComponents.DotNetBar.ExpandablePanel panelFlow;
        private DevComponents.DotNetBar.ItemPanel itemPanel3;
        private DevComponents.DotNetBar.ButtonItem btnmyapply;
        private DevComponents.DotNetBar.ButtonItem btnCheck;
        private DevComponents.DotNetBar.ButtonItem btnSupply;
        private DevComponents.DotNetBar.ButtonItem btnloadcar;
        private DevComponents.DotNetBar.ButtonItem btnTransfer;
        private DevComponents.DotNetBar.ButtonItem btnunload;
        private DevComponents.DotNetBar.ButtonItem btnbackcar;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label labuser;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevComponents.DotNetBar.ButtonX btnclose;
        private DevComponents.DotNetBar.LabelX labcheckstate;
        private DevComponents.DotNetBar.ButtonItem btnVehicleDept;
        private DevComponents.DotNetBar.ButtonItem btnDeptMaterielTypeReport;
    }
}