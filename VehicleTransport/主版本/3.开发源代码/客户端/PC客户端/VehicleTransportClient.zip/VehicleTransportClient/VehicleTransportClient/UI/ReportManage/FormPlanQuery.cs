﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VehicleTransportClient.UI.Report
{
    public partial class FormPlanQuery : Form
    {
        public FormPlanQuery()
        {
            InitializeComponent();
        }
    }
}
